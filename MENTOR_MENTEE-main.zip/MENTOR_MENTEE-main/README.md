# MentorIQ — Full Stack AI Mentor-Mentee System

## Project Structure
```
mihuna/
├── frontend/          # React + Vite frontend
│   └── src/
│       ├── components/    # Reusable UI components
│       ├── pages/         # Route pages
│       ├── contexts/      # React contexts
│       ├── hooks/         # Custom hooks
│       └── utils/         # Utility functions
├── backend/           # Node.js + Express backend
│   ├── routes/        # API routes
│   ├── middleware/    # Auth & validation
│   └── services/      # Business logic
└── ESP32/             # Arduino/ESP32 firmware code
```

## Setup Instructions

### 1. Frontend
```bash
cd frontend
npm install
npm run dev
```

### 2. Backend
```bash
cd backend
npm install
cp .env.example .env   # fill in your credentials
node server.js
```

### 3. Firebase Setup
- Create a Firebase project at console.firebase.google.com
- Enable Authentication (Google + Email/Password)
- Enable Firestore Database
- Add your config to frontend/src/utils/firebase.js

### 4. ESP32 Setup
- Open ESP32/firmware.ino in Arduino IDE
- Install ESP32 board support
- Install libraries: WiFi, WebServer, FingerprintSensor
- Flash firmware to ESP32
- Copy IP from Serial Monitor and paste in Dashboard

## Environment Variables (backend/.env)
```
PORT=5000
FIREBASE_SERVICE_ACCOUNT=./serviceAccountKey.json
EMAIL_USER=your@gmail.com
EMAIL_PASS=your_app_password
JWT_SECRET=your_jwt_secret
```
