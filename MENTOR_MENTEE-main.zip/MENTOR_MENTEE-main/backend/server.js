const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));

app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:5173'],
  credentials: true,
}));

app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/students', rateLimit({ windowMs: 60 * 1000, max: 120 }));
app.use('/mentors', rateLimit({ windowMs: 60 * 1000, max: 120 }));
app.use('/meetings', rateLimit({ windowMs: 60 * 1000, max: 120 }));
app.use('/devices', rateLimit({ windowMs: 60 * 1000, max: 120 }));

const calculateRisk = (attendance, marks, behaviour, financialIssue) => {
  const normalizedBehaviour = ((Number(behaviour) - 1) / 4) * 100;
  const score = 100
    - (0.4 * Number(attendance || 0))
    - (0.35 * Number(marks || 0))
    - (0.15 * Number(normalizedBehaviour || 0))
    + (0.1 * (financialIssue ? 50 : 0));
  return Math.max(0, Math.min(100, Math.round(score * 10) / 10));
};

const classifyRisk = (score) => {
  if (score >= 65) return 'High';
  if (score >= 35) return 'Medium';
  return 'Low';
};

const quickSort = (items, key = 'predicted_risk', descending = true) => {
  if (!items || items.length <= 1) return items || [];
  const pivot = items[Math.floor(items.length / 2)][key] ?? 0;
  const left = items.filter((item, index) => index !== Math.floor(items.length / 2) && (descending ? (item[key] ?? 0) > pivot : (item[key] ?? 0) < pivot));
  const middle = items.filter(item => (item[key] ?? 0) === pivot);
  const right = items.filter((item, index) => index !== Math.floor(items.length / 2) && (descending ? (item[key] ?? 0) < pivot : (item[key] ?? 0) > pivot));
  return [...quickSort(left, key, descending), ...middle, ...quickSort(right, key, descending)];
};

const createDemoStudents = () => ([
  { student_id: 'STU001', name: 'Arjun Mehta', department: 'CSE', attendance: 45, marks: 38, behaviour: 2, financial_issue: true, issue_feedback: 'Family financial crisis affecting studies', mentor_id: 'M001', fingerprint_id: 101, last_attendance: null, attendance_status: 'absent' },
  { student_id: 'STU002', name: 'Sneha Reddy', department: 'CSE', attendance: 82, marks: 78, behaviour: 4, financial_issue: false, issue_feedback: '', mentor_id: 'M001', fingerprint_id: 102, last_attendance: null, attendance_status: 'absent' },
  { student_id: 'STU003', name: 'Karthik Nair', department: 'ECE', attendance: 60, marks: 55, behaviour: 3, financial_issue: false, issue_feedback: 'Health issues', mentor_id: 'M002', fingerprint_id: 103, last_attendance: null, attendance_status: 'absent' },
].map(student => ({
  ...student,
  id: student.student_id,
  predicted_risk: calculateRisk(student.attendance, student.marks, student.behaviour, student.financial_issue),
  risk_level: classifyRisk(calculateRisk(student.attendance, student.marks, student.behaviour, student.financial_issue)),
  created_at: new Date().toISOString(),
})));

const createDemoMentors = () => ([
  { id: 'M001', mentor_id: 'M001', name: 'Dr. Priya Sharma', department: 'CSE', email: 'priya.sharma@college.edu', specialization: 'Machine Learning' },
  { id: 'M002', mentor_id: 'M002', name: 'Prof. Ramesh Kumar', department: 'ECE', email: 'ramesh.kumar@college.edu', specialization: 'VLSI Design' },
  { id: 'M003', mentor_id: 'M003', name: 'Dr. Anita Singh', department: 'MECH', email: 'anita.singh@college.edu', specialization: 'Thermal Engineering' },
]);

let db = {
  students: createDemoStudents(),
  mentors: createDemoMentors(),
  meetings: [
    { id: 'MTG001', meeting_id: 'MTG001', mentor_id: 'M001', student_id: 'STU001', date: '2026-04-10', status: 'scheduled', created_at: new Date().toISOString() },
    { id: 'MTG002', meeting_id: 'MTG002', mentor_id: 'M002', student_id: 'STU003', date: '2026-04-09', status: 'attended', created_at: new Date().toISOString() },
  ],
  devices: [
    { id: 'ESP32-001', device_id: 'ESP32-001', ip_address: '192.168.1.105', status: 'connected', last_seen: new Date().toISOString() },
  ],
};

const createTransporter = () => {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) return null;
  return nodemailer.createTransport({
    service: 'gmail',
    auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
  });
};

async function sendMeetingMissedEmail(meeting) {
  const student = db.students.find(item => item.student_id === meeting.student_id);
  const mentor = db.mentors.find(item => item.id === meeting.mentor_id);
  const transporter = createTransporter();

  if (!transporter) {
    console.log(`[GMAIL SIMULATION] missed meeting email for ${student?.name || meeting.student_id}`);
    return { simulated: true };
  }

  return transporter.sendMail({
    from: `"MentorIQ System" <${process.env.EMAIL_USER}>`,
    to: student?.email || process.env.EMAIL_USER,
    subject: 'Mentor meeting missed',
    html: `<p>Meeting with ${mentor?.name || meeting.mentor_id} on ${meeting.date} was marked missed.</p>`,
  });
}

function normalizeStudent(student) {
  const studentId = student.student_id || student.id || `STU_${uuidv4().slice(0, 6).toUpperCase()}`;
  const predicted_risk = calculateRisk(student.attendance, student.marks, student.behaviour, student.financial_issue);
  return {
    ...student,
    id: studentId,
    student_id: studentId,
    predicted_risk: Math.round(predicted_risk * 10) / 10,
    risk_level: classifyRisk(predicted_risk),
  };
}

function normalizeMeeting(meeting) {
  const meetingId = meeting.meeting_id || meeting.id || `MTG_${uuidv4().slice(0, 6).toUpperCase()}`;
  return {
    ...meeting,
    id: meetingId,
    meeting_id: meetingId,
    status: meeting.status || 'scheduled',
  };
}

function normalizeDevice(device) {
  const deviceId = device.device_id || device.id || `DEV_${uuidv4().slice(0, 6).toUpperCase()}`;
  return {
    ...device,
    id: deviceId,
    device_id: deviceId,
  };
}

app.get('/', (req, res) => {
  res.json({
    service: 'MentorIQ Simplified API',
    status: 'healthy',
    endpoints: ['/students', '/mentors', '/meetings', '/devices'],
  });
});

app.get('/students', (req, res) => {
  res.json({ success: true, count: db.students.length, data: quickSort(db.students, 'predicted_risk', true) });
});

app.post('/students', (req, res) => {
  const student = normalizeStudent(req.body);
  db.students.push(student);
  res.status(201).json({ success: true, data: student });
});

app.patch('/students/:id', (req, res) => {
  const index = db.students.findIndex(student => student.student_id === req.params.id || student.id === req.params.id);
  if (index < 0) return res.status(404).json({ error: 'Student not found' });
  db.students[index] = normalizeStudent({ ...db.students[index], ...req.body });
  res.json({ success: true, data: db.students[index] });
});

app.get('/mentors', (req, res) => {
  res.json({ success: true, count: db.mentors.length, data: db.mentors });
});

app.post('/mentors', (req, res) => {
  const mentorId = req.body.mentor_id || req.body.id || `M_${uuidv4().slice(0, 6).toUpperCase()}`;
  const mentor = { ...req.body, id: mentorId, mentor_id: mentorId };
  db.mentors.push(mentor);
  res.status(201).json({ success: true, data: mentor });
});

app.get('/meetings', (req, res) => {
  res.json({ success: true, count: db.meetings.length, data: db.meetings });
});

app.post('/meetings', async (req, res) => {
  const meeting = normalizeMeeting(req.body);
  db.meetings.push(meeting);
  if (meeting.status === 'missed') {
    await sendMeetingMissedEmail(meeting);
  }
  res.status(201).json({ success: true, data: meeting });
});

app.patch('/meetings/:id', async (req, res) => {
  const index = db.meetings.findIndex(meeting => meeting.meeting_id === req.params.id || meeting.id === req.params.id);
  if (index < 0) return res.status(404).json({ error: 'Meeting not found' });
  db.meetings[index] = normalizeMeeting({ ...db.meetings[index], ...req.body });
  if (db.meetings[index].status === 'missed') {
    await sendMeetingMissedEmail(db.meetings[index]);
  }
  res.json({ success: true, data: db.meetings[index] });
});

app.get('/devices', (req, res) => {
  res.json({ success: true, count: db.devices.length, data: db.devices });
});

app.post('/devices', (req, res) => {
  const device = normalizeDevice(req.body);
  db.devices.push(device);
  res.status(201).json({ success: true, data: device });
});

app.patch('/devices/:id', (req, res) => {
  const index = db.devices.findIndex(device => device.device_id === req.params.id || device.id === req.params.id);
  if (index < 0) return res.status(404).json({ error: 'Device not found' });
  db.devices[index] = normalizeDevice({ ...db.devices[index], ...req.body });
  res.json({ success: true, data: db.devices[index] });
});

app.use((req, res) => {
  res.status(404).json({ error: 'Route not found', path: req.path });
});

app.listen(PORT, () => {
  console.log(`MentorIQ simplified API running on port ${PORT}`);
});

module.exports = app;
