from __future__ import annotations

import os
import shutil
import socket
import subprocess
import threading
import webbrowser
from pathlib import Path

from flask import Flask, Response, send_from_directory

BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR / "frontend"
DIST_DIR = FRONTEND_DIR / "dist"

app = Flask(__name__, static_folder=str(DIST_DIR), static_url_path="")


def ensure_frontend_build() -> bool:
    if DIST_DIR.exists():
        return True

    if not FRONTEND_DIR.exists():
        print("Frontend folder not found. Expected: ./frontend")
        return False

    if os.getenv("AUTO_BUILD_FRONTEND", "1") != "1":
        return False

    npm_cmd = shutil.which("npm.cmd") or shutil.which("npm")
    if not npm_cmd:
        print("npm not found in PATH. Install Node.js or run frontend build manually.")
        return False

    print("No frontend build found. Running npm build...")

    try:
        if not (FRONTEND_DIR / "node_modules").exists():
            subprocess.run([npm_cmd, "install"], cwd=FRONTEND_DIR, check=True)
        subprocess.run([npm_cmd, "run", "build"], cwd=FRONTEND_DIR, check=True)
    except Exception as exc:
        print(f"Frontend build failed: {exc}")
        return False

    return DIST_DIR.exists()


@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_frontend(path: str):
    if DIST_DIR.exists():
        file_path = DIST_DIR / path
        if path and file_path.exists() and file_path.is_file():
            return send_from_directory(DIST_DIR, path)
        return send_from_directory(DIST_DIR, "index.html")

    return (
        "<h1>Frontend build not found</h1>"
        "<p>Run <code>npm run build</code> inside <code>frontend</code>, then restart app.py.</p>"
    )


@app.get("/favicon.ico")
def favicon() -> Response:
    favicon_file = DIST_DIR / "favicon.ico"
    if favicon_file.exists():
        return send_from_directory(DIST_DIR, "favicon.ico")
    return Response(status=204)


def get_local_ip() -> str:
    """Find a LAN IP address that other devices on the same network can access."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            # No data is sent. This is a safe way to discover the outbound interface IP.
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def open_browser(url: str) -> None:
    try:
        webbrowser.open(url)
    except Exception:
        pass


if __name__ == "__main__":
    ensure_frontend_build()

    port = int(os.getenv("PORT", "5000"))
    local_ip = get_local_ip()

    localhost_url = f"http://127.0.0.1:{port}"
    network_url = f"http://{local_ip}:{port}"

    print("\nServer starting...")
    print(f"Local URL:   {localhost_url}")
    print(f"Network URL: {network_url}")
    print("Open one of these links in your browser.\n")

    # Set OPEN_BROWSER=0 if you do not want auto-open behavior.
    if os.getenv("OPEN_BROWSER", "1") == "1":
        threading.Timer(0.8, open_browser, args=(localhost_url,)).start()

    app.run(host="0.0.0.0", port=port)
