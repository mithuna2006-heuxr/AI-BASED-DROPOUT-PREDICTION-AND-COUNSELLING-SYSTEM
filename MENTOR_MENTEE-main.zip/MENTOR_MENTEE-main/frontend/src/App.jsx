import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import { Toaster } from 'react-hot-toast';

// Pages
import LoginPage from './pages/LoginPage';
import AdminDashboard from './pages/AdminDashboard';
import MentorDashboard from './pages/MentorDashboard';
import StudentDashboard from './pages/StudentDashboard';
import StudentsPage from './pages/StudentsPage';
import MeetingsPage from './pages/MeetingsPage';
import AttendancePage from './pages/AttendancePage';
import ESP32Page from './pages/ESP32Page';
import NeuralGraphPage from './pages/NeuralGraphPage';
import UploadPage from './pages/UploadPage';
import Layout from './components/Layout';

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, userRole } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (allowedRoles && !allowedRoles.includes(userRole)) {
    return <Navigate to="/dashboard" replace />;
  }
  return children;
};

const DashboardRedirect = () => {
  const { userRole } = useAuth();
  if (userRole === 'admin') return <Navigate to="/admin" replace />;
  if (userRole === 'mentor') return <Navigate to="/mentor" replace />;
  return <Navigate to="/student" replace />;
};

const AppRoutes = () => {
  const { user } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/dashboard" /> : <LoginPage />} />
      <Route path="/dashboard" element={<ProtectedRoute><DashboardRedirect /></ProtectedRoute>} />
      
      <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
        <Route index element={<Navigate to="/dashboard" />} />
        
        {/* Admin Routes */}
        <Route path="admin" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <AdminDashboard />
          </ProtectedRoute>
        } />
        <Route path="upload" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <UploadPage />
          </ProtectedRoute>
        } />
        
        {/* Mentor Routes */}
        <Route path="mentor" element={
          <ProtectedRoute allowedRoles={['mentor', 'admin']}>
            <MentorDashboard />
          </ProtectedRoute>
        } />
        <Route path="meetings" element={
          <ProtectedRoute allowedRoles={['mentor', 'admin']}>
            <MeetingsPage />
          </ProtectedRoute>
        } />
        
        {/* Student Routes */}
        <Route path="student" element={
          <ProtectedRoute allowedRoles={['student', 'mentor', 'admin']}>
            <StudentDashboard />
          </ProtectedRoute>
        } />
        
        {/* Shared Routes */}
        <Route path="students" element={<ProtectedRoute><StudentsPage /></ProtectedRoute>} />
        <Route path="attendance" element={<ProtectedRoute><AttendancePage /></ProtectedRoute>} />
        <Route path="esp32" element={<ProtectedRoute><ESP32Page /></ProtectedRoute>} />
        <Route path="devices" element={<ProtectedRoute><ESP32Page /></ProtectedRoute>} />
        <Route path="neural" element={<ProtectedRoute><NeuralGraphPage /></ProtectedRoute>} />
      </Route>
      
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <AppRoutes />
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#0a1628',
              color: '#e2e8f0',
              border: '1px solid rgba(99,179,237,0.2)',
              borderRadius: '12px',
              fontSize: '0.875rem'
            },
            success: { iconTheme: { primary: '#48bb78', secondary: '#0a1628' } },
            error: { iconTheme: { primary: '#fc8181', secondary: '#0a1628' } }
          }}
        />
      </DataProvider>
    </AuthProvider>
  );
}

export default App;
