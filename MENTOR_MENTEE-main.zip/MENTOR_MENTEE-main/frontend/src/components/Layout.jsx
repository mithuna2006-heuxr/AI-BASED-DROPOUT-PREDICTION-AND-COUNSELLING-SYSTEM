import React, { useState } from 'react';
import { Outlet, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import {
  LayoutDashboard, Users, UserCheck, Calendar, Cpu,
  Share2, Upload, LogOut, Menu, X,
  Wifi, Activity
} from 'lucide-react';

const NAV_ADMIN = [
  { label: 'Overview', path: '/admin', icon: LayoutDashboard },
  { label: 'Upload Data', path: '/upload', icon: Upload },
  { label: 'Students', path: '/students', icon: Users },
  { label: 'Mentors', path: '/mentor', icon: UserCheck },
  { label: 'Meetings', path: '/meetings', icon: Calendar },
  { label: 'Attendance', path: '/attendance', icon: Activity },
  { label: 'ESP32 Device', path: '/esp32', icon: Cpu },
  { label: 'Neural Graph', path: '/neural', icon: Share2 },
  { label: 'Devices', path: '/devices', icon: Cpu },
];

const NAV_MENTOR = [
  { label: 'My Dashboard', path: '/mentor', icon: LayoutDashboard },
  { label: 'My Mentees', path: '/students', icon: Users },
  { label: 'Meetings', path: '/meetings', icon: Calendar },
  { label: 'Attendance', path: '/attendance', icon: Activity },
  { label: 'ESP32 Device', path: '/esp32', icon: Cpu },
  { label: 'Devices', path: '/devices', icon: Cpu },
];

const NAV_STUDENT = [
  { label: 'My Profile', path: '/student', icon: LayoutDashboard },
  { label: 'Attendance', path: '/attendance', icon: Activity },
  { label: 'My Mentor', path: '/mentor', icon: UserCheck },
  { label: 'Meetings', path: '/meetings', icon: Calendar },
];

const ROLE_COLORS = {
  admin: 'var(--color-accent-purple)',
  mentor: 'var(--color-accent-blue)',
  student: 'var(--color-accent-green)'
};

export default function Layout() {
  const { user, userRole, logout } = useAuth();
  const { esp32Connected, stats } = useData();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = userRole === 'admin' ? NAV_ADMIN : userRole === 'mentor' ? NAV_MENTOR : NAV_STUDENT;

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const initials = user?.displayName
    ? user.displayName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
    : '??';

  const avatarColors = ['#667eea', '#9f7aea', '#0bc5ea', '#48bb78', '#ed8936'];
  const avatarBg = avatarColors[initials.charCodeAt(0) % avatarColors.length];

  const getPageTitle = () => {
    const path = location.pathname;
    if (path === '/admin') return 'Admin Dashboard';
    if (path === '/mentor') return 'Mentor Dashboard';
    if (path === '/student') return 'Student Dashboard';
    if (path === '/upload') return 'Data Upload & Processing';
    if (path === '/students') return 'Students Management';
    if (path === '/meetings') return 'Meetings & Scheduling';
    if (path === '/attendance') return 'Attendance Tracking';
    if (path === '/esp32') return 'ESP32 IoT Device';
    if (path === '/devices') return 'Device Management';
    if (path === '/neural') return 'Neural Schema Graph';
    return 'MentorIQ';
  };

  return (
    <div className="app-layout">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div 
          onClick={() => setSidebarOpen(false)}
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 99, backdropFilter: 'blur(4px)' }}
        />
      )}

      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-logo">
          <div className="logo-text">🧠 MentorIQ</div>
          <div className="logo-subtitle">AI Mentor System</div>
        </div>

        <nav className="sidebar-nav">
          <div className="nav-section-label">Navigation</div>
          {navItems.map(item => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/admin' || item.path === '/mentor' || item.path === '/student'}
              className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
              onClick={() => setSidebarOpen(false)}
            >
              <item.icon className="nav-icon" size={18} />
              <span style={{ flex: 1 }}>{item.label}</span>
              {item.label === 'ESP32 Device' && esp32Connected && (
                <span className="badge-online" style={{ fontSize: '0.6rem', padding: '2px 6px', borderRadius: '999px', background: 'rgba(72,187,120,0.15)', color: 'var(--color-accent-green)', border: '1px solid rgba(72,187,120,0.2)' }}>LIVE</span>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">
          {/* ESP32 Status quick indicator */}
          <div style={{ 
            display: 'flex', alignItems: 'center', gap: '0.5rem',
            padding: '0.5rem 0.75rem', borderRadius: '8px',
            background: esp32Connected ? 'rgba(72,187,120,0.08)' : 'rgba(255,255,255,0.04)',
            border: `1px solid ${esp32Connected ? 'rgba(72,187,120,0.2)' : 'var(--color-border)'}`,
            marginBottom: '0.75rem'
          }}>
            <Wifi size={14} color={esp32Connected ? 'var(--color-accent-green)' : 'var(--text-muted)'} />
            <span style={{ fontSize: '0.75rem', color: esp32Connected ? 'var(--color-accent-green)' : 'var(--text-muted)', fontWeight: 600 }}>
              {esp32Connected ? 'ESP32 Connected' : 'No Device'}
            </span>
          </div>

          <div className="user-profile">
            <div className="avatar" style={{ background: avatarBg }}>{initials}</div>
            <div className="user-info">
              <div className="user-name">{user?.displayName || user?.email || 'User'}</div>
              <div className="user-role" style={{ color: ROLE_COLORS[userRole] }}>{userRole}</div>
            </div>
            <button
              onClick={handleLogout}
              className="btn btn-ghost btn-icon"
              style={{ padding: '6px', flexShrink: 0 }}
              title="Logout"
            >
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="main-content">
        <header className="top-header">
          <button
            className="btn btn-ghost btn-icon"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            style={{ display: 'none' }}
            id="menu-toggle"
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          
          <div>
            <div className="header-title">{getPageTitle()}</div>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
              {new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>

          <div className="header-actions">
            {/* Quick Stats */}
            <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
              {userRole !== 'student' && (
                <>
                  <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>High Risk</span>
                    <span style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--risk-high)' }}>{stats?.highRisk || 0}</span>
                  </div>
                  <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Today</span>
                    <span style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--color-accent-green)' }}>{stats?.attendanceToday || 0}</span>
                  </div>
                  <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Devices</span>
                    <span style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--color-accent-cyan)' }}>{stats?.activeDevices || 0}/{stats?.totalDevices || 0}</span>
                  </div>
                </>
              )}

              <NavLink to="/esp32" style={{ textDecoration: 'none' }}>
                <div style={{
                  display: 'flex', alignItems: 'center', gap: '0.4rem',
                  padding: '0.4rem 0.75rem',
                  borderRadius: '999px',
                  background: esp32Connected ? 'rgba(72,187,120,0.1)' : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${esp32Connected ? 'rgba(72,187,120,0.3)' : 'var(--color-border)'}`,
                  cursor: 'pointer'
                }}>
                  <div className={`status-dot ${esp32Connected ? 'connected' : 'disconnected'}`} />
                  <span style={{ fontSize: '0.75rem', fontWeight: 600, color: esp32Connected ? 'var(--color-accent-green)' : 'var(--text-muted)' }}>
                    {esp32Connected ? 'IoT Live' : 'Connect'}
                  </span>
                </div>
              </NavLink>
            </div>
          </div>
        </header>

        <main className="page-content">
          <Outlet />
        </main>
      </div>

      <style>{`
        @media (max-width: 1024px) {
          #menu-toggle { display: flex !important; }
        }
      `}</style>
    </div>
  );
}
