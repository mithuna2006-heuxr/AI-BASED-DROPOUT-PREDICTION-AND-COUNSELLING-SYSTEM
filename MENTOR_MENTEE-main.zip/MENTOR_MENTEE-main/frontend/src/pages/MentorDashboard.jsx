import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from 'recharts';

export default function MentorDashboard() {
  const { user } = useAuth();
  const { students, meetings, mentors } = useData();

  const currentMentor = mentors.find(mentor => mentor.email === user?.email || mentor.name === user?.displayName) || mentors[0];
  const myMentees = students.filter(student => student.mentor_id === currentMentor?.id);
  const myMeetings = meetings.filter(meeting => meeting.mentor_id === currentMentor?.id);

  const radarData = [
    { metric: 'Attendance', value: 72 },
    { metric: 'Marks', value: 65 },
    { metric: 'Behaviour', value: 80 },
    { metric: 'Engagement', value: 60 },
    { metric: 'Progress', value: 70 }
  ];

  return (
    <div className="animate-fade-in">
      <div style={{
        background: 'linear-gradient(135deg, rgba(102,126,234,0.12) 0%, rgba(159,122,234,0.12) 100%)',
        border: '1px solid rgba(159,122,234,0.2)',
        borderRadius: '16px', padding: '1.5rem 2rem', marginBottom: '2rem'
      }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 700 }}>
          Welcome, <span style={{ color: 'var(--color-accent-purple)' }}>{currentMentor?.name || user?.displayName || 'Mentor'}</span> 👨‍🏫
        </h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
          You have {myMentees.filter(s => s.risk_level === 'High').length} high-risk mentees requiring attention today
        </p>
      </div>

      <div className="stat-grid" style={{ marginBottom: '1.5rem' }}>
        {[
          { label: 'Mentees', value: myMentees.length, color: 'var(--color-accent-blue)' },
          { label: 'High Risk', value: myMentees.filter(s => s.risk_level === 'High').length, color: 'var(--risk-high)' },
          { label: 'Meetings', value: myMeetings.length, color: 'var(--color-accent-purple)' },
          { label: 'Alerts Sent', value: 3, color: 'var(--risk-medium)' }
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div className="stat-value" style={{ color: s.color, fontSize: '2rem' }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-title" style={{ marginBottom: '1rem' }}>📊 Mentee Performance Radar</div>
          <div style={{ height: '220px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="rgba(99,179,237,0.1)" />
                <PolarAngleAxis dataKey="metric" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} />
                <Radar name="Avg" dataKey="value" stroke="#9f7aea" fill="#9f7aea" fillOpacity={0.2} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card">
          <div className="card-title" style={{ marginBottom: '1rem' }}>👥 My Mentees</div>
          {myMentees.map(s => (
            <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem', padding: '0.75rem', background: 'rgba(255,255,255,0.03)', borderRadius: '10px' }}>
              <div className="avatar avatar-sm" style={{ background: s.risk_level === 'High' ? 'rgba(252,129,129,0.2)' : 'rgba(72,187,120,0.2)', color: s.risk_level === 'High' ? 'var(--risk-high)' : 'var(--color-accent-green)' }}>
                {s.name?.[0]}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '0.875rem', fontWeight: 600 }}>{s.name}</div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{s.department}</div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Last attendance: {s.last_attendance ? new Date(s.last_attendance).toLocaleString() : 'No attendance yet'}</div>
              </div>
              <span className={`badge ${s.risk_level === 'High' ? 'badge-high' : s.risk_level === 'Medium' ? 'badge-medium' : 'badge-low'}`}>
                {s.risk_level}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
