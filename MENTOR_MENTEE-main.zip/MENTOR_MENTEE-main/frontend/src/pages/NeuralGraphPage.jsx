import React, { useEffect, useRef } from 'react';
import { useData } from '../contexts/DataContext';
import * as d3 from 'd3';

export default function NeuralGraphPage() {
  const { students, mentors } = useData();
  const svgRef = useRef(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const w = svgRef.current.clientWidth || 900;
    const h = 480;

    d3.select(svgRef.current).selectAll('*').remove();

    const svg = d3.select(svgRef.current)
      .attr('width', w)
      .attr('height', h);

    // Gradient filter for glow
    const defs = svg.append('defs');
    
    const glowFilter = (id, color) => {
      const filter = defs.append('filter').attr('id', id);
      filter.append('feGaussianBlur').attr('stdDeviation', '3').attr('result', 'coloredBlur');
      const feMerge = filter.append('feMerge');
      feMerge.append('feMergeNode').attr('in', 'coloredBlur');
      feMerge.append('feMergeNode').attr('in', 'SourceGraphic');
    };

    glowFilter('glow-blue', '#63b3ed');
    glowFilter('glow-red', '#fc8181');
    glowFilter('glow-green', '#48bb78');
    glowFilter('glow-purple', '#9f7aea');

    // Build nodes & links
    const nodes = [];
    const links = [];

    // Mentor nodes
    mentors.forEach(m => {
      nodes.push({
        id: m.id,
        label: m.name.split(' ').slice(-1)[0],
        fullLabel: m.name,
        type: 'mentor',
        dept: m.department,
        radius: 28,
        color: '#9f7aea',
        glowFilter: 'url(#glow-purple)'
      });
    });

    // Student nodes
    students.forEach(s => {
      const color = s.risk_level === 'High' ? '#fc8181' : s.risk_level === 'Medium' ? '#f6d860' : '#48bb78';
      const glow = s.risk_level === 'High' ? 'url(#glow-red)' : s.risk_level === 'Low' ? 'url(#glow-green)' : 'url(#glow-blue)';
      nodes.push({
        id: s.id,
        label: s.name?.split(' ')[0] || s.id,
        fullLabel: s.name,
        type: 'student',
        dept: s.department,
        risk: s.risk_level,
        riskScore: s.predicted_risk,
        radius: s.risk_level === 'High' ? 18 : 14,
        color,
        glowFilter: glow
      });

      if (s.mentor_id) {
        links.push({
          source: s.mentor_id,
          target: s.id,
          risk: s.risk_level
        });
      }
    });

    const simulation = d3.forceSimulation(nodes)
      .force('link', d3.forceLink(links).id(d => d.id).distance(d => d.risk === 'High' ? 80 : 110).strength(0.8))
      .force('charge', d3.forceManyBody().strength(-300))
      .force('center', d3.forceCenter(w / 2, h / 2))
      .force('collision', d3.forceCollide().radius(d => d.radius + 15))
      .force('x', d3.forceX(w / 2).strength(0.02))
      .force('y', d3.forceY(h / 2).strength(0.02));

    // Background grid
    const gridGroup = svg.append('g').attr('class', 'grid');
    for (let x = 0; x < w; x += 50) {
      gridGroup.append('line')
        .attr('x1', x).attr('y1', 0).attr('x2', x).attr('y2', h)
        .attr('stroke', 'rgba(99,179,237,0.04)').attr('stroke-width', 1);
    }
    for (let y = 0; y < h; y += 50) {
      gridGroup.append('line')
        .attr('x1', 0).attr('y1', y).attr('x2', w).attr('y2', y)
        .attr('stroke', 'rgba(99,179,237,0.04)').attr('stroke-width', 1);
    }

    // Links
    const link = svg.append('g').selectAll('line')
      .data(links)
      .join('line')
      .attr('stroke', d => d.risk === 'High' ? 'rgba(252,129,129,0.4)' : d.risk === 'Medium' ? 'rgba(246,216,96,0.3)' : 'rgba(72,187,120,0.3)')
      .attr('stroke-width', d => d.risk === 'High' ? 2 : 1.5)
      .attr('stroke-dasharray', d => d.risk === 'High' ? '4,2' : 'none');

    // Pulse animation for high-risk links
    link.filter(d => d.risk === 'High')
      .append('animate')
      .attr('attributeName', 'stroke-opacity')
      .attr('values', '0.4;0.9;0.4')
      .attr('dur', '2s')
      .attr('repeatCount', 'indefinite');

    // Node groups
    const node = svg.append('g').selectAll('g')
      .data(nodes)
      .join('g')
      .attr('cursor', 'pointer')
      .call(d3.drag()
        .on('start', (event, d) => {
          if (!event.active) simulation.alphaTarget(0.3).restart();
          d.fx = d.x; d.fy = d.y;
        })
        .on('drag', (event, d) => { d.fx = event.x; d.fy = event.y; })
        .on('end', (event, d) => {
          if (!event.active) simulation.alphaTarget(0);
          d.fx = null; d.fy = null;
        })
      );

    // Outer ring for mentors
    node.filter(d => d.type === 'mentor')
      .append('circle')
      .attr('r', d => d.radius + 6)
      .attr('fill', 'none')
      .attr('stroke', '#9f7aea')
      .attr('stroke-width', 1)
      .attr('stroke-opacity', 0.4)
      .attr('stroke-dasharray', '4,3');

    // Node circles
    node.append('circle')
      .attr('r', d => d.radius)
      .attr('fill', d => `${d.color}22`)
      .attr('stroke', d => d.color)
      .attr('stroke-width', d => d.type === 'mentor' ? 2.5 : 2)
      .attr('filter', d => d.glowFilter);

    // Pulse ring for high-risk students
    node.filter(d => d.risk === 'High')
      .append('circle')
      .attr('r', d => d.radius + 4)
      .attr('fill', 'none')
      .attr('stroke', '#fc8181')
      .attr('stroke-width', 1.5)
      .attr('stroke-opacity', 0)
      .each(function() {
        d3.select(this)
          .append('animate').attr('attributeName', 'r').attr('values', `18;28;18`).attr('dur', '2.5s').attr('repeatCount', 'indefinite');
        d3.select(this)
          .append('animate').attr('attributeName', 'stroke-opacity').attr('values', '0.6;0;0.6').attr('dur', '2.5s').attr('repeatCount', 'indefinite');
      });

    // Icon inside node
    node.append('text')
      .attr('text-anchor', 'middle')
      .attr('dominant-baseline', 'central')
      .attr('font-size', d => d.type === 'mentor' ? '14px' : '10px')
      .text(d => d.type === 'mentor' ? '👨‍🏫' : d.risk === 'High' ? '⚠' : '🎓');

    // Label below node
    node.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', d => d.radius + 14)
      .attr('font-size', '11px')
      .attr('font-family', 'Inter, sans-serif')
      .attr('font-weight', d => d.type === 'mentor' ? '700' : '500')
      .attr('fill', d => d.color)
      .text(d => d.label);

    // Dept label for mentors
    node.filter(d => d.type === 'mentor')
      .append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', d => d.radius + 26)
      .attr('font-size', '9px')
      .attr('font-family', 'Inter, sans-serif')
      .attr('fill', 'rgba(148,163,184,0.7)')
      .text(d => d.dept);

    // Tooltip
    const tooltip = d3.select('body').append('div')
      .style('position', 'fixed')
      .style('background', 'rgba(10,22,40,0.95)')
      .style('border', '1px solid rgba(99,179,237,0.3)')
      .style('border-radius', '10px')
      .style('padding', '10px 14px')
      .style('font-size', '12px')
      .style('font-family', 'Inter, sans-serif')
      .style('color', '#e2e8f0')
      .style('pointer-events', 'none')
      .style('z-index', '9999')
      .style('opacity', 0)
      .style('transition', 'opacity 0.2s');

    node
      .on('mouseover', (event, d) => {
        tooltip.transition().duration(200).style('opacity', 1);
        const content = d.type === 'mentor'
          ? `<strong>${d.fullLabel}</strong><br/>📚 ${d.dept} Mentor`
          : `<strong>${d.fullLabel}</strong><br/>Dept: ${d.dept}<br/>Risk: <span style="color:${d.color}">${d.risk} (${d.riskScore}%)</span>`;
        tooltip.html(content)
          .style('left', (event.clientX + 12) + 'px')
          .style('top', (event.clientY - 30) + 'px');
      })
      .on('mousemove', (event) => {
        tooltip.style('left', (event.clientX + 12) + 'px').style('top', (event.clientY - 30) + 'px');
      })
      .on('mouseout', () => tooltip.transition().duration(200).style('opacity', 0));

    simulation.on('tick', () => {
      link
        .attr('x1', d => d.source.x).attr('y1', d => d.source.y)
        .attr('x2', d => d.target.x).attr('y2', d => d.target.y);
      node.attr('transform', d => `translate(${
        Math.max(d.radius, Math.min(w - d.radius, d.x))
      },${
        Math.max(d.radius, Math.min(h - d.radius, d.y))
      })`);
    });

    return () => {
      simulation.stop();
      tooltip.remove();
    };
  }, [students, mentors]);

  return (
    <div className="animate-fade-in">
      <div style={{ marginBottom: '1.5rem', display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', fontWeight: 700 }}>Neural Schema Visualization</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
            D3.js force-directed graph showing mentor–mentee relationships and risk levels
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.78rem' }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#9f7aea', boxShadow: '0 0 8px #9f7aea' }} />
            <span style={{ color: 'var(--text-muted)' }}>Mentor</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.78rem' }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#fc8181', boxShadow: '0 0 8px #fc8181' }} />
            <span style={{ color: 'var(--text-muted)' }}>High Risk</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.78rem' }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#f6d860', boxShadow: '0 0 8px #f6d860' }} />
            <span style={{ color: 'var(--text-muted)' }}>Medium Risk</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.78rem' }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#48bb78', boxShadow: '0 0 8px #48bb78' }} />
            <span style={{ color: 'var(--text-muted)' }}>Low Risk</span>
          </div>
        </div>
      </div>

      <div className="card neural-graph-container" style={{ height: '500px', padding: 0 }}>
        <svg ref={svgRef} style={{ width: '100%', height: '100%', borderRadius: '16px' }} />
      </div>

      {/* Stats below graph */}
      <div className="grid-3" style={{ marginTop: '1.5rem' }}>
        {[
          { label: 'Total Nodes', value: students.length + mentors.length, color: 'var(--color-accent-blue)' },
          { label: 'Mentor Links', value: students.filter(s => s.mentor_id).length, color: 'var(--color-accent-purple)' },
          { label: 'High-Risk Edges', value: students.filter(s => s.risk_level === 'High' && s.mentor_id).length, color: 'var(--risk-high)' }
        ].map(stat => (
          <div key={stat.label} className="card" style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '2rem', fontWeight: 800, color: stat.color }}>{stat.value}</div>
            <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>{stat.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
