import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import { Bell, Mail, MessageSquare, AlertTriangle, CheckCircle, Send, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AlertsPage() {
  const { students, alerts, sendAlert, addAlert } = useData();
  const { userRole } = useAuth();
  const [form, setForm] = useState({ student_id: '', message: '', method: 'email' });
  const [sending, setSending] = useState(false);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!form.student_id || !form.message) {
      toast.error('Select a student and enter a message');
      return;
    }
    setSending(true);
    await sendAlert(form.student_id, form.message);
    setSending(false);
    toast.success('Alert sent successfully!');
    setForm({ student_id: '', message: '', method: 'email' });
  };

  const presetMessages = [
    "You missed your mentor meeting. Please attend the next session.",
    "Your attendance is below the required threshold. Please improve attendance.",
    "Your current academic performance is concerning. Please meet your mentor urgently.",
    "Financial support is available. Please contact the administration office.",
    "Reminder: Mentor meeting scheduled for tomorrow. Please confirm attendance."
  ];

  return (
    <div className="animate-fade-in">
      <div style={{ marginBottom: '1.5rem' }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', fontWeight: 700 }}>Alerts & Notifications</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Send email, SMS, and push alerts to students and mentors</p>
      </div>

      <div className="grid-2">
        {/* Send Alert Form */}
        {(userRole === 'admin' || userRole === 'mentor') && (
          <div className="card">
            <div className="card-title" style={{ marginBottom: '1.25rem' }}>
              <Send size={16} style={{ display: 'inline', marginRight: '8px', color: 'var(--color-accent-blue)' }} />
              Send Alert
            </div>
            <form onSubmit={handleSend}>
              <div className="form-group">
                <label className="form-label">Select Student</label>
                <select
                  className="form-input form-select"
                  value={form.student_id}
                  onChange={e => setForm({ ...form, student_id: e.target.value })}
                >
                  <option value="">Choose student...</option>
                  {students.filter(s => s.risk_level === 'High').length > 0 && (
                    <optgroup label="⚠ High Risk">
                      {students.filter(s => s.risk_level === 'High').map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.department})</option>
                      ))}
                    </optgroup>
                  )}
                  {students.filter(s => s.risk_level === 'Medium').length > 0 && (
                    <optgroup label="🟡 Medium Risk">
                      {students.filter(s => s.risk_level === 'Medium').map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.department})</option>
                      ))}
                    </optgroup>
                  )}
                  {students.filter(s => s.risk_level === 'Low').length > 0 && (
                    <optgroup label="🟢 Low Risk">
                      {students.filter(s => s.risk_level === 'Low').map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.department})</option>
                      ))}
                    </optgroup>
                  )}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Alert Channel</label>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  {[
                    { key: 'email', label: 'Email', icon: <Mail size={13} /> },
                    { key: 'sms', label: 'SMS (GSM)', icon: <MessageSquare size={13} /> },
                    { key: 'both', label: 'Both', icon: <Bell size={13} /> }
                  ].map(method => (
                    <button
                      key={method.key}
                      type="button"
                      className={`btn ${form.method === method.key ? 'btn-primary' : 'btn-ghost'} btn-sm`}
                      onClick={() => setForm({ ...form, method: method.key })}
                      style={{ flex: 1 }}
                    >
                      {method.icon} {method.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Message</label>
                <textarea
                  className="form-input"
                  rows={4}
                  placeholder="Type your alert message..."
                  value={form.message}
                  onChange={e => setForm({ ...form, message: e.target.value })}
                />
              </div>

              {/* Preset Messages */}
              <div className="form-group">
                <label className="form-label">Quick Presets</label>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                  {presetMessages.map((msg, i) => (
                    <button
                      key={i}
                      type="button"
                      className="btn btn-ghost btn-sm"
                      onClick={() => setForm({ ...form, message: msg })}
                      style={{ textAlign: 'left', justifyContent: 'flex-start', fontSize: '0.78rem', height: 'auto', whiteSpace: 'normal', lineHeight: '1.4' }}
                    >
                      💬 {msg}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="btn btn-primary btn-full"
                disabled={sending}
              >
                {sending ? (
                  <><div className="spinner" style={{ width: '15px', height: '15px' }} /> Sending...</>
                ) : (
                  <><Send size={15} /> Send Alert</>
                )}
              </button>
            </form>

            {/* Bulk Alert */}
            <div className="divider" />
            <div>
              <div style={{ fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.75rem' }}>Bulk Alerts</div>
              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => {
                    const highRiskStudents = students.filter(s => s.risk_level === 'High');
                    highRiskStudents.forEach(s => sendAlert(s.id, 'Your academic risk level is High. Please meet your mentor immediately.'));
                    toast.success(`Alerts sent to ${highRiskStudents.length} high-risk students`);
                  }}
                >
                  <AlertTriangle size={13} /> Alert All High-Risk
                </button>
                <button
                  className="btn btn-ghost btn-sm"
                  onClick={() => {
                    students.filter(s => s.attendance < 60).forEach(s =>
                      sendAlert(s.id, 'Your attendance is below 60%. Please improve immediately.')
                    );
                    toast.success('Attendance alerts sent!');
                  }}
                >
                  📊 Low Attendance Alert
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Alert Log */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">
              <Bell size={16} style={{ display: 'inline', marginRight: '8px' }} />
              Alert History ({alerts?.length || 0})
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', maxHeight: '600px', overflowY: 'auto' }}>
            {(!alerts || alerts.length === 0) && (
              <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                <Bell size={24} style={{ marginBottom: '0.5rem', opacity: 0.3 }} />
                <p>No alerts yet</p>
              </div>
            )}
            {(alerts || []).map(alert => (
              <div key={alert.id} style={{
                padding: '0.875rem',
                background: alert.type === 'success' ? 'rgba(72,187,120,0.05)' : alert.type === 'error' ? 'rgba(252,129,129,0.05)' : 'rgba(99,179,237,0.05)',
                border: `1px solid ${alert.type === 'success' ? 'rgba(72,187,120,0.15)' : alert.type === 'error' ? 'rgba(252,129,129,0.15)' : 'rgba(99,179,237,0.15)'}`,
                borderRadius: '10px'
              }}>
                <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.1rem', flexShrink: 0 }}>
                    {alert.type === 'success' ? '✅' : alert.type === 'error' ? '❌' : '📢'}
                  </span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: '0.85rem', color: 'var(--text-primary)', lineHeight: 1.5 }}>{alert.message}</div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                      {alert.time ? new Date(alert.time).toLocaleString() : 'Just now'}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Integration Guide */}
      <div className="card" style={{ marginTop: '1.5rem', background: 'linear-gradient(135deg, rgba(159,122,234,0.06) 0%, rgba(99,179,237,0.06) 100%)', border: '1px solid rgba(159,122,234,0.15)' }}>
        <div className="card-title" style={{ marginBottom: '1rem' }}>📡 Alert Integration Guide</div>
        <div className="grid-3">
          <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '10px', border: '1px solid var(--color-border)' }}>
            <div style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>📧</div>
            <div style={{ fontWeight: 600, fontSize: '0.875rem', marginBottom: '0.25rem' }}>Gmail API</div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              Configure Gmail SMTP in backend <code style={{ color: 'var(--color-accent-cyan)' }}>EMAIL_USER</code> and <code style={{ color: 'var(--color-accent-cyan)' }}>EMAIL_PASS</code> env vars
            </div>
          </div>
          <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '10px', border: '1px solid var(--color-border)' }}>
            <div style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>📱</div>
            <div style={{ fontWeight: 600, fontSize: '0.875rem', marginBottom: '0.25rem' }}>SIM800L GSM</div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              ESP32 triggers SMS via <code style={{ color: 'var(--color-accent-cyan)' }}>AT+CMGS</code> command over serial (TX/RX pins)
            </div>
          </div>
          <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '10px', border: '1px solid var(--color-border)' }}>
            <div style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>🔔</div>
            <div style={{ fontWeight: 600, fontSize: '0.875rem', marginBottom: '0.25rem' }}>Firebase FCM</div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              Enable Firebase Cloud Messaging for browser push notifications to mentors and students
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
