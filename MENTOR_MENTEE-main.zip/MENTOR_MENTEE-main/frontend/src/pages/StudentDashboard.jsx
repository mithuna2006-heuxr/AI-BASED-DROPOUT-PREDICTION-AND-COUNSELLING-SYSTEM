import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { getRiskGradient } from '../utils/mlEngine';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

const DEMO_TREND = [
  { month: 'Jan', risk: 80 },
  { month: 'Feb', risk: 75 },
  { month: 'Mar', risk: 70 },
  { month: 'Apr', risk: 68 },
];

export default function StudentDashboard() {
  const { user } = useAuth();
  const { students, meetings, mentors } = useData();

  const myProfile = students[0];
  const myMentor = mentors.find(m => m.id === myProfile?.mentor_id) || mentors[0];
  const myMeetings = meetings.slice(0, 2);

  if (!myProfile) return <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>Loading...</div>;

  const riskColor = myProfile.risk_level === 'High' ? 'var(--risk-high)' : myProfile.risk_level === 'Medium' ? 'var(--risk-medium)' : 'var(--risk-low)';

  return (
    <div className="animate-fade-in">
      {/* Profile Banner */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(99,179,237,0.1) 0%, rgba(72,187,120,0.08) 100%)',
        border: '1px solid rgba(99,179,237,0.2)',
        borderRadius: '16px', padding: '1.5rem 2rem', marginBottom: '2rem',
        display: 'flex', alignItems: 'center', gap: '1.5rem', flexWrap: 'wrap'
      }}>
        <div className="avatar avatar-xl" style={{
          background: getRiskGradient(myProfile.predicted_risk),
          fontSize: '1.5rem', flexShrink: 0
        }}>
          {myProfile.name?.[0] || '?'}
        </div>
        <div style={{ flex: 1 }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', fontWeight: 700, marginBottom: '4px' }}>
            {myProfile.name}
          </h2>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem', display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
            <span>🎓 {myProfile.department}</span>
            <span>🔖 {myProfile.id}</span>
            <span>👨‍🏫 Mentor: {myProfile.assigned_mentor}</span>
            <span>📅 Attendance: {myProfile.attendance_status || 'absent'}</span>
          </div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>AI Risk Score</div>
          <div style={{ fontSize: '2.5rem', fontWeight: 800, fontFamily: 'var(--font-display)', color: riskColor }}>
            {myProfile.predicted_risk}%
          </div>
          <span className={`badge ${myProfile.risk_level === 'High' ? 'badge-high' : myProfile.risk_level === 'Medium' ? 'badge-medium' : 'badge-low'}`}>
            {myProfile.risk_level} Risk
          </span>
        </div>
      </div>

      <div className="stat-grid" style={{ marginBottom: '1.5rem' }}>
        {[
          { label: 'Attendance', value: `${myProfile.attendance}%`, color: myProfile.attendance < 60 ? 'var(--risk-high)' : 'var(--color-accent-green)', icon: '📅' },
          { label: 'Marks', value: `${myProfile.marks}%`, color: myProfile.marks < 50 ? 'var(--risk-high)' : 'var(--color-accent-blue)', icon: '📊' },
          { label: 'Behaviour', value: `${myProfile.behaviour}/5`, color: 'var(--color-accent-purple)', icon: '⭐' },
          { label: 'Meetings', value: myMeetings.length, color: 'var(--color-accent-cyan)', icon: '📅' }
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>{s.icon}</div>
            <div className="stat-value" style={{ color: s.color, fontSize: '1.75rem' }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        {/* Risk Trend */}
        <div className="card">
          <div className="card-title" style={{ marginBottom: '1rem' }}>📈 My Risk Trend</div>
          <div style={{ height: '180px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={DEMO_TREND}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(99,179,237,0.05)" />
                <XAxis dataKey="month" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 11 }} axisLine={false} tickLine={false} domain={[0,100]} />
                <Tooltip />
                <Line type="monotone" dataKey="risk" stroke="var(--risk-high)" strokeWidth={2} dot={{ fill: 'var(--risk-high)', r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p style={{ fontSize: '0.78rem', color: 'var(--color-accent-green)', textAlign: 'center', marginTop: '0.5rem' }}>
            ↓ Risk is decreasing — Good progress!
          </p>
        </div>

        {/* Mentor Info */}
        <div className="card">
          <div className="card-title" style={{ marginBottom: '1.25rem' }}>👨‍🏫 My Mentor</div>
          {myMentor ? (
            <div>
              <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', marginBottom: '1.25rem' }}>
                <div className="avatar avatar-lg" style={{ background: 'linear-gradient(135deg, #9f7aea, #667eea)', fontSize: '1.2rem' }}>
                  {myMentor.name?.[0] || 'M'}
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '1rem' }}>{myMentor.name}</div>
                  <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>{myMentor.specialization}</div>
                  <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>📧 {myMentor.email}</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '0.75rem', flexDirection: 'column' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Department</span>
                  <span className="badge badge-info">{myMentor.department}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Total Mentees</span>
                  <span style={{ fontWeight: 600 }}>{myMentor.menteeCount}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Meetings Scheduled</span>
                  <span style={{ fontWeight: 600 }}>{myMentor.meetingsScheduled}</span>
                </div>
              </div>
            </div>
          ) : (
            <p style={{ color: 'var(--text-muted)', textAlign: 'center' }}>No mentor assigned yet</p>
          )}
        </div>
      </div>

      <div className="card" style={{ marginTop: '1.5rem' }}>
        <div className="card-title" style={{ marginBottom: '1rem' }}>🕐 Attendance Status</div>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
          Last attendance: {myProfile.last_attendance ? new Date(myProfile.last_attendance).toLocaleString() : 'No attendance yet'}
        </p>
      </div>
    </div>
  );
}
