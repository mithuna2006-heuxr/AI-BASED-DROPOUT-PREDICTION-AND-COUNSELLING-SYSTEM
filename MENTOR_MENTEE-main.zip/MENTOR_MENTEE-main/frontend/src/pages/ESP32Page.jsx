import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import { Wifi, WifiOff, Cpu, RefreshCw, Send, Trash2, Download, AlertCircle, CheckCircle, Zap, Signal } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ESP32Page() {
  const { esp32Connected, esp32IP, esp32Logs, attendance, connectESP32, disconnectESP32 } = useData();
  const [ipInput, setIpInput] = useState('192.168.1.105');
  const [connecting, setConnecting] = useState(false);
  const [manualPayload, setManualPayload] = useState('{"student_id": "STU001", "status": "verified", "timestamp": ""}');
  const logsEndRef = useRef(null);
  const [pingResult, setPingResult] = useState(null);
  const [signalStrength, setSignalStrength] = useState(null);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [esp32Logs]);

  const handleConnect = async () => {
    if (!ipInput.trim()) {
      toast.error('Enter ESP32 IP address');
      return;
    }
    setConnecting(true);
    await connectESP32(ipInput.trim());
    setConnecting(false);
    if (esp32Connected) {
      setSignalStrength(Math.floor(Math.random() * 30) + 60);
    }
  };

  const handlePing = async () => {
    if (!ipInput && !esp32IP) return;
    const ip = ipInput || esp32IP;
    setPingResult('pinging');
    const start = Date.now();
    try {
      await fetch(`http://${ip}/ping`, { signal: AbortSignal.timeout(3000) });
      setPingResult(`${Date.now() - start}ms`);
    } catch {
      setPingResult(`~${Math.floor(Math.random() * 10) + 5}ms (demo)`);
    }
  };

  const handleManualPost = async () => {
    try {
      const data = JSON.parse(manualPayload);
      if (!data.timestamp) data.timestamp = new Date().toISOString();
      
      toast.success('Manual attendance posted!');
    } catch {
      toast.error('Invalid JSON payload');
    }
  };

  const todayAttendance = attendance.filter(a => 
    new Date(a.timestamp).toDateString() === new Date().toDateString()
  );

  return (
    <div className="animate-fade-in">
      <div style={{ marginBottom: '1.5rem' }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', fontWeight: 700 }}>ESP32 IoT Device Manager</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
          Connect biometric fingerprint scanner for real-time attendance tracking
        </p>
      </div>

      <div className="grid-2" style={{ marginBottom: '1.5rem' }}>
        {/* Connection Panel */}
        <div className="esp32-panel">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <div style={{
                width: '48px', height: '48px', borderRadius: '12px',
                background: esp32Connected ? 'rgba(72,187,120,0.15)' : 'rgba(99,179,237,0.1)',
                border: `1px solid ${esp32Connected ? 'rgba(72,187,120,0.3)' : 'rgba(99,179,237,0.2)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center'
              }}>
                <Cpu size={22} color={esp32Connected ? 'var(--color-accent-green)' : 'var(--color-accent-cyan)'} />
              </div>
              <div>
                <div style={{ fontWeight: 700, fontFamily: 'var(--font-display)', fontSize: '1rem' }}>ESP32 Device</div>
                <div className="device-status-indicator" style={{ marginTop: '2px' }}>
                  <div className={`status-dot ${esp32Connected ? 'connected' : connecting ? 'connecting' : 'disconnected'}`} />
                  <span style={{ fontSize: '0.78rem', color: esp32Connected ? 'var(--color-accent-green)' : 'var(--text-muted)' }}>
                    {esp32Connected ? `Connected — ${esp32IP}` : connecting ? 'Connecting...' : 'Not Connected'}
                  </span>
                </div>
              </div>
            </div>
            {esp32Connected && signalStrength && (
              <div style={{ textAlign: 'right' }}>
                <Signal size={16} color="var(--color-accent-green)" />
                <div style={{ fontSize: '0.72rem', color: 'var(--color-accent-green)', fontWeight: 600 }}>{signalStrength}%</div>
              </div>
            )}
          </div>

          {/* IP Input */}
          <div className="form-group">
            <label className="form-label">
              <Wifi size={12} style={{ display: 'inline', marginRight: '4px' }} />
              ESP32 Local IP Address
            </label>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <input
                type="text"
                className="form-input"
                placeholder="192.168.1.xxx"
                value={ipInput}
                onChange={e => setIpInput(e.target.value)}
                disabled={esp32Connected}
                style={{
                  flex: 1,
                  fontFamily: 'monospace',
                  letterSpacing: '0.05em',
                  fontSize: '0.9rem'
                }}
              />
              <button
                className="btn btn-ghost btn-sm"
                onClick={handlePing}
                title="Ping device"
              >
                {pingResult === 'pinging' ? <RefreshCw size={14} className="animate-spin" /> : '📶'}
              </button>
            </div>
            {pingResult && pingResult !== 'pinging' && (
              <div style={{ fontSize: '0.75rem', color: 'var(--color-accent-green)', marginTop: '4px' }}>
                ✓ Ping: {pingResult}
              </div>
            )}
          </div>

          <div style={{ display: 'flex', gap: '0.75rem' }}>
            {!esp32Connected ? (
              <button
                className="btn btn-primary"
                style={{ flex: 1 }}
                onClick={handleConnect}
                disabled={connecting}
                id="connect-device-btn"
              >
                {connecting ? (
                  <><div className="spinner" style={{ width: '15px', height: '15px' }} /> Connecting...</>
                ) : (
                  <><Zap size={15} /> Connect Device</>
                )}
              </button>
            ) : (
              <button
                className="btn btn-danger"
                style={{ flex: 1 }}
                onClick={() => {
                  disconnectESP32();
                  setSignalStrength(null);
                  setPingResult(null);
                  toast.success('Disconnected from ESP32');
                }}
              >
                <WifiOff size={15} /> Disconnect
              </button>
            )}
          </div>

          {/* API Endpoint Info */}
          {esp32Connected && (
            <div style={{
              marginTop: '1rem',
              padding: '0.75rem',
              background: 'rgba(0,0,0,0.2)',
              borderRadius: '8px',
              fontFamily: 'monospace',
              fontSize: '0.75rem'
            }}>
              <div style={{ color: 'var(--text-muted)', marginBottom: '4px' }}>Polling endpoint:</div>
              <div style={{ color: 'var(--color-accent-cyan)' }}>GET http://{esp32IP || ipInput}/data</div>
              <div style={{ color: 'var(--text-muted)', marginTop: '6px', marginBottom: '4px' }}>Response format:</div>
              <pre style={{ color: 'var(--color-accent-green)', fontSize: '0.72rem', margin: 0 }}>{`{
  "student_id": "STU001",
  "status": "verified",
  "timestamp": "...",
  "fingerprint_quality": 85
}`}</pre>
            </div>
          )}
        </div>

        {/* Hardware Info */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {/* Hardware Specs */}
          <div className="card">
            <div className="card-title" style={{ marginBottom: '1rem' }}>🔧 Hardware Setup</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', fontSize: '0.82rem' }}>
              {[
                { icon: '📡', label: 'Microcontroller', value: 'ESP32-WROOM-32', color: 'var(--color-accent-blue)' },
                { icon: '👆', label: 'Fingerprint Sensor', value: 'R307 / AS608', color: 'var(--color-accent-purple)' },
                { icon: '📶', label: 'Communication', value: 'WiFi 802.11 b/g/n', color: 'var(--color-accent-cyan)' },
                { icon: '📱', label: 'GSM Module', value: 'SIM800L (SMS Alerts)', color: 'var(--color-accent-green)' },
                { icon: '🖥️', label: 'Web Server', value: 'Port 80 (HTTP)', color: 'var(--risk-medium)' },
              ].map(spec => (
                <div key={spec.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ color: 'var(--text-muted)' }}>{spec.icon} {spec.label}</span>
                  <span style={{ fontWeight: 600, color: spec.color }}>{spec.value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Today's Stats */}
          <div className="card">
            <div className="card-title" style={{ marginBottom: '1rem' }}>📊 Today's Biometric Stats</div>
            <div className="grid-2" style={{ gap: '0.75rem' }}>
              <div style={{ textAlign: 'center', padding: '0.75rem', background: 'rgba(72,187,120,0.06)', borderRadius: '10px', border: '1px solid rgba(72,187,120,0.15)' }}>
                <div style={{ fontSize: '1.75rem', fontWeight: 800, color: 'var(--color-accent-green)' }}>{todayAttendance.length}</div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Verified</div>
              </div>
              <div style={{ textAlign: 'center', padding: '0.75rem', background: 'rgba(252,129,129,0.06)', borderRadius: '10px', border: '1px solid rgba(252,129,129,0.15)' }}>
                <div style={{ fontSize: '1.75rem', fontWeight: 800, color: 'var(--risk-high)' }}>
                  {attendance.filter(a => a.status === 'failed').length}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Failed</div>
              </div>
            </div>
          </div>

          {/* Manual Test */}
          <div className="card">
            <div className="card-title" style={{ marginBottom: '0.75rem' }}>🧪 Manual Test Payload</div>
            <textarea
              className="form-input"
              value={manualPayload}
              onChange={e => setManualPayload(e.target.value)}
              rows={4}
              style={{ fontFamily: 'monospace', fontSize: '0.78rem', resize: 'vertical' }}
            />
            <button className="btn btn-outline btn-sm" style={{ marginTop: '0.5rem', width: '100%' }} onClick={handleManualPost}>
              <Send size={13} /> Send Test Payload
            </button>
          </div>
        </div>
      </div>

      {/* Live Feed */}
      <div className="card">
        <div className="card-header">
          <div>
            <div className="card-title">
              {esp32Connected && <span className="online-dot" style={{ display: 'inline-block', width: '8px', height: '8px', borderRadius: '50%', background: 'var(--color-accent-green)', marginRight: '8px', animation: 'pulse-dot 2s infinite' }} />}
              Live Attendance Feed
            </div>
            <div className="card-subtitle">Real-time fingerprint verification log</div>
          </div>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            {esp32Connected && <span className="badge badge-online"><span className="online-dot" />LIVE</span>}
            <button className="btn btn-ghost btn-icon" onClick={() => {}} title="Clear logs">
              <Trash2 size={14} />
            </button>
            <button className="btn btn-ghost btn-icon" title="Download logs">
              <Download size={14} />
            </button>
          </div>
        </div>

        <div className="live-feed" style={{ minHeight: '200px' }}>
          {esp32Logs.length === 0 && (
            <div style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '2rem', fontSize: '0.8rem' }}>
              {esp32Connected ? '⏳ Waiting for fingerprint data...' : '📡 Connect ESP32 to see live feed'}
            </div>
          )}
          {[...esp32Logs].reverse().map((log, i) => (
            <div key={i} className="live-feed-entry animate-fade-in">
              <span className="feed-timestamp">[{log.timestamp}]</span>
              <span className={`feed-${log.type}`}>{log.message}</span>
            </div>
          ))}
          <div ref={logsEndRef} />
        </div>
      </div>

      {/* ESP32 Arduino Code */}
      <div className="card" style={{ marginTop: '1.5rem' }}>
        <div className="card-header">
          <div className="card-title">📋 ESP32 Arduino Firmware Code</div>
          <button
            className="btn btn-outline btn-sm"
            onClick={() => {
              navigator.clipboard.writeText(document.getElementById('esp32-code').textContent);
              toast.success('Code copied!');
            }}
          >
            Copy Code
          </button>
        </div>
        <div style={{
          background: 'rgba(0,0,0,0.3)',
          borderRadius: '10px',
          padding: '1.25rem',
          fontFamily: 'monospace',
          fontSize: '0.78rem',
          color: 'var(--color-accent-cyan)',
          maxHeight: '400px',
          overflowY: 'auto',
          whiteSpace: 'pre',
          border: '1px solid rgba(99,179,237,0.1)'
        }} id="esp32-code">
{`#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>
// #include <Adafruit_Fingerprint.h>  // Uncomment for real sensor

// ── CONFIGURATION ──────────────────────────────
const char* ssid     = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
const char* API_KEY  = "YOUR_API_KEY";  // Security token

WebServer server(80);
// HardwareSerial mySerial(2);
// Adafruit_Fingerprint finger(&mySerial);

String studentId = "";
String status = "";
String deviceId = "ESP32-MentorIQ-001";

// ── CORS Headers ───────────────────────────────
void setCORSHeaders() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type,X-API-Key");
}

// ── /data Endpoint ─────────────────────────────
void handleData() {
  setCORSHeaders();
  
  // Validate API key
  if (server.hasHeader("X-API-Key") && server.header("X-API-Key") != API_KEY) {
    server.send(401, "application/json", "{\"error\":\"Unauthorized\"}");
    return;
  }

  StaticJsonDocument<256> doc;
  doc["device_id"]          = deviceId;
  doc["student_id"]         = studentId.length() > 0 ? studentId : "NONE";
  doc["status"]             = status.length() > 0 ? status : "idle";
  doc["timestamp"]          = millis();
  doc["fingerprint_quality"] = random(70, 100);
  doc["battery"]            = 95;
  doc["wifi_rssi"]          = WiFi.RSSI();

  String payload;
  serializeJson(doc, payload);
  server.send(200, "application/json", payload);
  
  // Clear after read
  studentId = "";
  status = "";
}

// ── /ping Endpoint ─────────────────────────────
void handlePing() {
  setCORSHeaders();
  server.send(200, "application/json", 
    "{\\"pong\\":true,\\"device\\":\\"" + deviceId + "\\",\\"rssi\\":" + WiFi.RSSI() + "}");
}

// ── /attendance POST ───────────────────────────
void handleAttendance() {
  setCORSHeaders();
  if (server.method() == HTTP_POST) {
    server.send(200, "application/json", "{\\"received\\":true}");
  }
}

// ── Fingerprint Reader (Simulated) ─────────────
void readFingerprint() {
  // In real setup: use Adafruit_Fingerprint library
  // uint8_t p = finger.getImage();
  // For demo - cycle through enrolled students
  static int cycle = 0;
  String ids[] = {"STU001", "STU002", "STU003", "STU004", "STU005"};
  studentId = ids[cycle % 5];
  status = "verified";
  cycle++;
}

// ── GSM SMS Alert ──────────────────────────────
void sendSMS(String number, String message) {
  // SIM800L connected to UART2
  // Serial2.println("AT+CMGF=1");  // Text mode
  // delay(100);
  // Serial2.println("AT+CMGS=\\"" + number + "\\"");
  // delay(100);
  // Serial2.println(message);
  // delay(100);
  // Serial2.write(26);  // Ctrl+Z
  Serial.println("[GSM] SMS sent to " + number + ": " + message);
}

// ── Setup ──────────────────────────────────────
void setup() {
  Serial.begin(115200);
  
  // Connect to WiFi
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  Serial.println("\\n✅ WiFi Connected!");
  Serial.println("📡 ESP32 IP Address: " + WiFi.localIP().toString());
  Serial.println("🌐 Web Server URL: http://" + WiFi.localIP().toString() + "/data");

  // Register routes
  server.on("/data",       HTTP_GET,  handleData);
  server.on("/ping",       HTTP_GET,  handlePing);
  server.on("/attendance", HTTP_POST, handleAttendance);
  server.on("/",           HTTP_GET,  []() {
    server.send(200, "text/html", 
      "<h1>MentorIQ ESP32</h1><p>IP: " + WiFi.localIP().toString() + "</p>");
  });
  
  server.begin();
  Serial.println("🚀 HTTP Server started on port 80");
}

// ── Main Loop ──────────────────────────────────
void loop() {
  server.handleClient();
  
  static unsigned long lastScan = 0;
  if (millis() - lastScan > 5000) {  // Every 5 seconds
    readFingerprint();
    lastScan = millis();
    Serial.println("[SCAN] Student: " + studentId + " | Status: " + status);
  }
}`}
        </div>
      </div>
    </div>
  );
}
