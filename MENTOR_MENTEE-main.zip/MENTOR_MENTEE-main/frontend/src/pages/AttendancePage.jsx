import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import { Activity, CheckCircle, XCircle, Fingerprint, Calendar, Download, Filter } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';

export default function AttendancePage() {
  const { students, esp32Connected, esp32IP } = useData();
  const { userRole } = useAuth();
  const [filterDate, setFilterDate] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [filterStudent, setFilterStudent] = useState('All');

  const filtered = students.filter(student => {
    const matchStatus = filterStatus === 'All' || student.attendance_status === filterStatus;
    const matchStudent = filterStudent === 'All' || student.student_id === filterStudent;
    return matchStatus && matchStudent;
  });

  const presentCount = students.filter(student => student.attendance_status === 'present').length;
  const absentCount = students.filter(student => student.attendance_status === 'absent').length;

  const exportCSV = () => {
    const headers = ['Student ID', 'Student Name', 'Department', 'Attendance Status', 'Last Attendance', 'Fingerprint ID'];
    const rows = filtered.map(student => [
      student.student_id,
      student.name,
      student.department,
      student.attendance_status,
      student.last_attendance || '',
      student.fingerprint_id || '',
    ]);
    const csv = [headers, ...rows].map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `student_attendance_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="animate-fade-in">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', fontWeight: 700 }}>Biometric Attendance</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
            Student attendance status directly from the students collection
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
          {esp32Connected && (
            <span className="badge badge-online">
              <span className="online-dot" />
              {esp32IP} LIVE
            </span>
          )}
          <button className="btn btn-outline btn-sm" onClick={exportCSV}>
            <Download size={14} /> Export CSV
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="stat-grid" style={{ marginBottom: '1.5rem' }}>
        {[
          { label: 'Total Students', value: students.length, color: 'var(--color-accent-blue)', icon: '📊' },
          { label: 'Present', value: presentCount, color: 'var(--color-accent-cyan)', icon: '📅' },
          { label: 'Absent', value: absentCount, color: 'var(--color-accent-green)', icon: '✅' },
          { label: 'Fingerprint IDs', value: students.filter(student => student.fingerprint_id).length, color: 'var(--risk-high)', icon: '👆' }
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>{s.icon}</div>
            <div className="stat-value" style={{ color: s.color, fontSize: '2rem' }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2" style={{ marginBottom: '1.5rem' }}>
        {/* Filters */}
        <div className="card">
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
            <Filter size={15} color="var(--text-muted)" />
            <input
              type="date"
              className="form-input"
              value={filterDate}
              onChange={e => setFilterDate(e.target.value)}
              style={{ flex: 1, minWidth: '140px' }}
            />
            <select className="form-input form-select" value={filterStatus} onChange={e => setFilterStatus(e.target.value)} style={{ width: 'auto' }}>
              <option value="All">All Status</option>
              <option value="present">Present</option>
              <option value="absent">Absent</option>
            </select>
            {userRole !== 'student' && (
              <select className="form-input form-select" value={filterStudent} onChange={e => setFilterStudent(e.target.value)} style={{ width: 'auto' }}>
                <option value="All">All Students</option>
                {students.map(s => <option key={s.student_id} value={s.student_id}>{s.name}</option>)}
              </select>
            )}
          </div>
        </div>

        {/* ESP32 Status */}
        <div className="esp32-panel" style={{ padding: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: '0.9rem', marginBottom: '4px' }}>
                <Fingerprint size={16} style={{ display: 'inline', marginRight: '6px', color: 'var(--color-accent-cyan)' }} />
                Fingerprint Scanner
              </div>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                {esp32Connected ? `Connected — ${esp32IP}` : 'Not connected — Go to Devices page'}
              </div>
            </div>
            <div className={`status-dot ${esp32Connected ? 'connected' : 'disconnected'}`} style={{ width: '14px', height: '14px' }} />
          </div>
        </div>
      </div>

      {/* Attendance Log */}
      <div className="card" style={{ marginBottom: '1.5rem', padding: 0 }}>
        <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--color-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div className="card-title">Attendance Status ({filtered.length})</div>
        </div>
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Student</th>
                <th>Fingerprint</th>
                <th>Last Attendance</th>
                <th>Mentor</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5} style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
                    No student attendance data found
                  </td>
                </tr>
              )}
              {filtered.map((student, i) => {
                return (
                  <tr key={student.student_id || i}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                        <div className="avatar avatar-sm" style={{
                          background: student.attendance_status === 'present' ? 'rgba(72,187,120,0.2)' : 'rgba(252,129,129,0.2)',
                          color: student.attendance_status === 'present' ? 'var(--color-accent-green)' : 'var(--risk-high)'
                        }}>
                          {student.name?.[0] || '?'}
                        </div>
                        <div>
                          <div style={{ fontWeight: 600, fontSize: '0.875rem' }}>{student.name}</div>
                          <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{student.student_id}</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span style={{ fontFamily: 'monospace', color: 'var(--color-accent-cyan)' }}>{student.fingerprint_id || '—'}</span>
                    </td>
                    <td>
                      <div style={{ fontSize: '0.875rem' }}>{student.last_attendance ? new Date(student.last_attendance).toLocaleString() : 'No attendance yet'}</div>
                    </td>
                    <td>
                      <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{student.assigned_mentor || 'Unassigned'}</span>
                    </td>
                    <td>
                      {student.attendance_status === 'present' ? (
                        <span className="badge badge-low"><CheckCircle size={10} /> Present</span>
                      ) : (
                        <span className="badge badge-high"><XCircle size={10} /> Absent</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Student Attendance Summary */}
      {userRole !== 'student' && (
        <div className="card">
          <div className="card-header">
            <div className="card-title">Student Attendance Summary</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {students.map(s => {
              return (
                <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: '1rem', padding: '0.5rem 0' }}>
                  <div className="avatar avatar-sm" style={{
                    background: s.risk_level === 'High' ? 'rgba(252,129,129,0.2)' : 'rgba(72,187,120,0.2)',
                    color: s.risk_level === 'High' ? 'var(--risk-high)' : 'var(--color-accent-green)'
                  }}>
                    {s.name?.[0] || '?'}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>{s.name}</span>
                      <span style={{ fontSize: '0.8rem', fontWeight: 700, color: s.attendance_status === 'present' ? 'var(--color-accent-green)' : 'var(--risk-high)' }}>
                        {s.attendance_status}
                      </span>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${s.attendance}%`, background: s.attendance < 60 ? 'var(--gradient-danger)' : 'var(--gradient-success)' }} />
                    </div>
                  </div>
                </div>
              );
            })}
            {studentSummary.length === 0 && (
              <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '1rem' }}>No student data</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
