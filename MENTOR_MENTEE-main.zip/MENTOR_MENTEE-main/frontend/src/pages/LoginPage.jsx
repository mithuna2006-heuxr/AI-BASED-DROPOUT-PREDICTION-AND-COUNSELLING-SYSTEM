import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

const ROLES = [
  { key: 'admin', label: 'Admin', icon: '🛡️', desc: 'Full system access' },
  { key: 'mentor', label: 'Mentor', icon: '👨‍🏫', desc: 'Manage mentees' },
  { key: 'student', label: 'Student', icon: '🎓', desc: 'View your profile' }
];

export default function LoginPage() {
  const { loginWithGoogle, loginWithEmail, registerWithEmail, loginDemo } = useAuth();
  const navigate = useNavigate();
  
  const [mode, setMode] = useState('login'); // login | register
  const [selectedRole, setSelectedRole] = useState('student');
  const [form, setForm] = useState({ email: '', password: '', name: '' });
  const [loading, setLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('');

  const handleDemoLogin = (role) => {
    loginDemo(role);
    toast.success(`Logged in as ${role} (Demo Mode)`);
    navigate('/dashboard');
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    const res = await loginWithGoogle(selectedRole);
    setLoading(false);
    if (res.success) {
      toast.success('Logged in with Google!');
      navigate('/dashboard');
    } else {
      toast.error('Google login failed. Use Demo Mode instead.');
    }
  };

  const handleSendOTP = () => {
    if (!form.email.includes('@')) {
      toast.error('Enter a valid email');
      return;
    }
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(code);
    setOtpSent(true);
    toast.success(`OTP sent! (Demo: ${code})`);
  };

  const handleEmailAuth = async (e) => {
    e.preventDefault();
    if (otpSent && otp !== generatedOtp) {
      toast.error('Invalid OTP');
      return;
    }
    
    setLoading(true);
    let res;
    if (mode === 'register') {
      res = await registerWithEmail(form.email, form.password, form.name, selectedRole);
    } else {
      res = await loginWithEmail(form.email, form.password, selectedRole);
    }
    setLoading(false);
    
    if (res.success) {
      toast.success(`Logged in as ${selectedRole}!`);
      navigate('/dashboard');
    } else {
      toast.error(res.error || 'Auth failed. Try Demo Mode.');
    }
  };

  return (
    <div className="auth-page">
      {/* Animated background rings */}
      <div className="auth-bg-ring" style={{
        width: '600px', height: '600px',
        top: '50%', left: '50%',
        transform: 'translate(-50%, -50%)',
        borderColor: 'rgba(99,179,237,0.1)',
        animation: 'rotate-ring 30s linear infinite'
      }} />
      <div className="auth-bg-ring" style={{
        width: '400px', height: '400px',
        top: '50%', left: '50%',
        transform: 'translate(-50%, -50%)',
        borderColor: 'rgba(159,122,234,0.1)',
        animation: 'rotate-ring 20s linear infinite reverse'
      }} />
      
      {/* Floating particles */}
      {[...Array(12)].map((_, i) => (
        <div key={i} style={{
          position: 'fixed',
          width: `${Math.random() * 4 + 2}px`,
          height: `${Math.random() * 4 + 2}px`,
          borderRadius: '50%',
          background: i % 3 === 0 ? 'rgba(99,179,237,0.4)' : i % 3 === 1 ? 'rgba(159,122,234,0.4)' : 'rgba(11,197,234,0.4)',
          top: `${Math.random() * 100}%`,
          left: `${Math.random() * 100}%`,
          animation: `float ${4 + Math.random() * 4}s ease-in-out infinite`,
          animationDelay: `${Math.random() * 4}s`
        }} />
      ))}

      <div className="auth-card animate-slide-up">
        <div className="auth-logo">
          <div className="logo-icon">🧠</div>
          <h1>MentorIQ</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
            AI-Powered Mentor Management
          </p>
        </div>

        {/* Role Selector */}
        <div className="form-label" style={{ marginBottom: '0.5rem' }}>Select Your Role</div>
        <div className="role-grid">
          {ROLES.map(role => (
            <div
              key={role.key}
              className={`role-card ${selectedRole === role.key ? 'selected' : ''}`}
              onClick={() => setSelectedRole(role.key)}
            >
              <div className="role-icon">{role.icon}</div>
              <div className="role-name">{role.label}</div>
            </div>
          ))}
        </div>

        {/* Demo Login Buttons */}
        <div style={{
          background: 'rgba(99,179,237,0.05)',
          border: '1px solid rgba(99,179,237,0.15)',
          borderRadius: '12px',
          padding: '1rem',
          marginBottom: '1.25rem'
        }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '0.75rem', textAlign: 'center' }}>
            ⚡ Quick Demo Access (No Setup Required)
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.5rem' }}>
            {ROLES.map(role => (
              <button
                key={role.key}
                className="btn btn-outline btn-sm"
                style={{ flexDirection: 'column', gap: '2px', padding: '0.5rem', fontSize: '0.78rem' }}
                onClick={() => handleDemoLogin(role.key)}
              >
                <span>{role.icon}</span>
                <span>{role.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="auth-divider">or sign in with account</div>

        {/* Google Login */}
        <button className="google-btn" onClick={handleGoogleLogin} disabled={loading}>
          <svg width="20" height="20" viewBox="0 0 48 48">
            <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"/>
            <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"/>
            <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"/>
            <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"/>
          </svg>
          Continue with Google
        </button>

        <div className="auth-divider">or email login</div>

        {/* Email Auth Form */}
        <form onSubmit={handleEmailAuth}>
          {mode === 'register' && (
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input
                type="text"
                className="form-input"
                placeholder="Your full name"
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
              />
            </div>
          )}
          
          <div className="form-group">
            <label className="form-label">Email Address</label>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <input
                type="email"
                className="form-input"
                placeholder="you@example.com"
                value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                style={{ flex: 1 }}
              />
              <button
                type="button"
                className="btn btn-outline btn-sm"
                onClick={handleSendOTP}
                style={{ flexShrink: 0, fontSize: '0.75rem' }}
              >
                OTP
              </button>
            </div>
          </div>

          {otpSent && (
            <div className="form-group animate-fade-in">
              <label className="form-label">Enter OTP</label>
              <input
                type="text"
                className="form-input"
                placeholder="6-digit code"
                value={otp}
                onChange={e => setOtp(e.target.value)}
                maxLength={6}
              />
            </div>
          )}

          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              className="form-input"
              placeholder="••••••••"
              value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })}
              required
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary btn-full"
            disabled={loading}
          >
            {loading ? (
              <><div className="spinner" style={{ width: '16px', height: '16px' }} /> Processing...</>
            ) : (
              mode === 'register' ? '🚀 Create Account' : '🔐 Sign In'
            )}
          </button>
        </form>

        <div style={{ textAlign: 'center', marginTop: '1.25rem', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
          {mode === 'login' ? (
            <>Don't have an account? <button className="btn btn-ghost" onClick={() => setMode('register')} style={{ padding: '0', color: 'var(--color-accent-blue)', fontWeight: 600, fontSize: '0.85rem' }}>Register</button></>
          ) : (
            <>Already have an account? <button className="btn btn-ghost" onClick={() => setMode('login')} style={{ padding: '0', color: 'var(--color-accent-blue)', fontWeight: 600, fontSize: '0.85rem' }}>Sign In</button></>
          )}
        </div>

        {/* Security Note */}
        <div style={{ 
          marginTop: '1.25rem', padding: '0.75rem', 
          background: 'rgba(72,187,120,0.05)',
          border: '1px solid rgba(72,187,120,0.15)',
          borderRadius: '8px',
          textAlign: 'center'
        }}>
          <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
            🔒 Secured by Firebase Auth • AES-256 Encryption • GDPR Compliant
          </p>
        </div>
      </div>
    </div>
  );
}
