import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import { Calendar, Plus, Clock, CheckCircle, X, Video, MapPin, Send } from 'lucide-react';
import toast from 'react-hot-toast';
import { format, addDays, startOfWeek, isSameDay } from 'date-fns';

const STATUS_BADGE = {
  scheduled: 'badge-info',
  completed: 'badge-low',
  missed: 'badge-high',
  cancelled: 'badge-medium'
};

export default function MeetingsPage() {
  const { meetings, students, mentors, scheduleMeeting, updateMeetingStatus, triggerMissedMeetingEmail } = useData();
  const { userRole, user } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [viewMode, setViewMode] = useState('list'); // list | calendar
  const [form, setForm] = useState({
    mentor_id: '',
    student_id: '',
    title: '',
    date: '',
    time: '10:00',
    notes: '',
    type: 'in-person' // in-person | virtual
  });

  // Filter meetings by role
  const visibleMeetings = meetings.filter(m => {
    if (userRole === 'admin') return true;
    if (userRole === 'mentor') return m.mentor_id === user?.uid || true; // show all for demo
    return m.student_id === user?.uid || true;
  });

  // Calendar week
  const weekStart = startOfWeek(selectedDate, { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title || !form.date || !form.time) {
      toast.error('Fill in all required fields');
      return;
    }
    
    const student = students.find(s => s.id === form.student_id);
    const mentor = mentors.find(m => m.id === form.mentor_id);
    
    scheduleMeeting({
      ...form,
      student_name: student?.name || 'Student',
      mentor_name: mentor?.name || 'Mentor'
    });
    
    toast.success('Meeting scheduled!');
    setShowForm(false);
    setForm({ mentor_id: '', student_id: '', title: '', date: '', time: '10:00', notes: '', type: 'in-person' });
  };

  const handleMissedAlert = (meeting) => {
    updateMeetingStatus(meeting.meeting_id || meeting.id, 'missed');
    triggerMissedMeetingEmail(meeting);
    toast.success('Missed meeting recorded and Gmail email queued.');
  };

  return (
    <div className="animate-fade-in">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', fontWeight: 700 }}>Meetings & Scheduling</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
            {meetings.filter(m => m.status === 'scheduled').length} upcoming • {meetings.filter(m => m.status === 'completed').length} completed
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button
            className={`btn ${viewMode === 'list' ? 'btn-primary' : 'btn-ghost'} btn-sm`}
            onClick={() => setViewMode('list')}
          >List</button>
          <button
            className={`btn ${viewMode === 'calendar' ? 'btn-primary' : 'btn-ghost'} btn-sm`}
            onClick={() => setViewMode('calendar')}
          >📅 Calendar</button>
          {(userRole === 'admin' || userRole === 'mentor') && (
            <button className="btn btn-primary btn-sm" onClick={() => setShowForm(true)}>
              <Plus size={14} /> Schedule Meeting
            </button>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="stat-grid" style={{ marginBottom: '1.5rem' }}>
        {[
          { label: 'Total', value: meetings.length, color: 'var(--color-accent-blue)' },
          { label: 'Upcoming', value: meetings.filter(m => m.status === 'scheduled').length, color: 'var(--color-accent-purple)' },
          { label: 'Completed', value: meetings.filter(m => m.status === 'completed').length, color: 'var(--color-accent-green)' },
          { label: 'Missed', value: meetings.filter(m => m.status === 'missed').length, color: 'var(--risk-high)' }
        ].map(stat => (
          <div key={stat.label} className="stat-card">
            <div className="stat-value" style={{ color: stat.color, fontSize: '1.75rem' }}>{stat.value}</div>
            <div className="stat-label">{stat.label} Meetings</div>
          </div>
        ))}
      </div>

      {/* Calendar View */}
      {viewMode === 'calendar' && (
        <div className="card" style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
            <button className="btn btn-ghost btn-sm" onClick={() => setSelectedDate(addDays(selectedDate, -7))}>← Prev</button>
            <div style={{ fontWeight: 700, fontFamily: 'var(--font-display)' }}>
              {format(weekStart, 'MMM d')} – {format(addDays(weekStart, 6), 'MMM d, yyyy')}
            </div>
            <button className="btn btn-ghost btn-sm" onClick={() => setSelectedDate(addDays(selectedDate, 7))}>Next →</button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '0.5rem' }}>
            {weekDays.map(day => {
              const dayMeetings = meetings.filter(m => m.date === format(day, 'yyyy-MM-dd'));
              const isToday = isSameDay(day, new Date());
              return (
                <div key={day.toISOString()} style={{
                  padding: '0.75rem 0.5rem',
                  borderRadius: '10px',
                  background: isToday ? 'rgba(99,179,237,0.1)' : 'rgba(255,255,255,0.02)',
                  border: `1px solid ${isToday ? 'rgba(99,179,237,0.3)' : 'var(--color-border)'}`,
                  minHeight: '100px'
                }}>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textAlign: 'center', marginBottom: '4px' }}>
                    {format(day, 'EEE')}
                  </div>
                  <div style={{ fontSize: '0.9rem', fontWeight: 700, textAlign: 'center', color: isToday ? 'var(--color-accent-blue)' : 'var(--text-primary)', marginBottom: '8px' }}>
                    {format(day, 'd')}
                  </div>
                  {dayMeetings.map(m => (
                    <div key={m.id} style={{
                      fontSize: '0.65rem', padding: '3px 6px', borderRadius: '4px',
                      background: m.status === 'scheduled' ? 'rgba(99,179,237,0.15)' : 'rgba(72,187,120,0.15)',
                      color: m.status === 'scheduled' ? 'var(--color-accent-blue)' : 'var(--color-accent-green)',
                      marginBottom: '3px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'
                    }}>
                      {m.time} {m.title}
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Meeting List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        {visibleMeetings.length === 0 && (
          <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📅</div>
            <p style={{ color: 'var(--text-muted)' }}>No meetings scheduled yet</p>
          </div>
        )}
        {visibleMeetings.map(meeting => (
          <div key={meeting.id} className="card" style={{ padding: '1.25rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '0.75rem' }}>
              <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                <div style={{
                  width: '44px', height: '44px', borderRadius: '10px', flexShrink: 0,
                  background: meeting.status === 'scheduled' ? 'rgba(99,179,237,0.1)' : meeting.status === 'completed' ? 'rgba(72,187,120,0.1)' : 'rgba(252,129,129,0.1)',
                  border: `1px solid ${meeting.status === 'scheduled' ? 'rgba(99,179,237,0.3)' : meeting.status === 'completed' ? 'rgba(72,187,120,0.3)' : 'rgba(252,129,129,0.3)'}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem'
                }}>
                  {meeting.type === 'virtual' ? '💻' : '🤝'}
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.95rem', marginBottom: '4px' }}>{meeting.title}</div>
                  <div style={{ display: 'flex', gap: '1rem', fontSize: '0.8rem', color: 'var(--text-muted)', flexWrap: 'wrap' }}>
                    <span><Calendar size={12} style={{ display: 'inline', marginRight: '4px' }} />{meeting.date}</span>
                    <span><Clock size={12} style={{ display: 'inline', marginRight: '4px' }} />{meeting.time}</span>
                    <span>{meeting.mentor_name || meeting.mentor_id}</span>
                    <span>→ {meeting.student_name || meeting.student_id}</span>
                  </div>
                  {meeting.notes && (
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '6px', fontStyle: 'italic' }}>
                      📝 {meeting.notes}
                    </div>
                  )}
                </div>
              </div>
              <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                <span className={`badge ${STATUS_BADGE[meeting.status] || 'badge-info'}`}>
                  {meeting.status}
                </span>
                {meeting.status === 'scheduled' && (userRole === 'admin' || userRole === 'mentor') && (
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleMissedAlert(meeting)}
                    title="Mark as missed and send alert"
                  >
                    <Send size={12} /> Alert
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Schedule Meeting Modal */}
      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title"><Calendar size={18} style={{ display: 'inline', marginRight: '8px' }} />Schedule Meeting</div>
              <button className="btn btn-ghost btn-icon" onClick={() => setShowForm(false)}><X size={16} /></button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Meeting Title *</label>
                <input type="text" className="form-input" placeholder="e.g., Academic Progress Review" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} required />
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Mentor</label>
                  <select className="form-input form-select" value={form.mentor_id} onChange={e => setForm({ ...form, mentor_id: e.target.value })}>
                    <option value="">Select Mentor</option>
                    {mentors.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Student</label>
                  <select className="form-input form-select" value={form.student_id} onChange={e => setForm({ ...form, student_id: e.target.value })}>
                    <option value="">Select Student</option>
                    {students.map(s => <option key={s.id} value={s.id}>{s.name} — {s.risk_level} Risk</option>)}
                  </select>
                </div>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Date *</label>
                  <input type="date" className="form-input" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required min={new Date().toISOString().split('T')[0]} />
                </div>
                <div className="form-group">
                  <label className="form-label">Time *</label>
                  <input type="time" className="form-input" value={form.time} onChange={e => setForm({ ...form, time: e.target.value })} required />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Meeting Type</label>
                <div style={{ display: 'flex', gap: '0.75rem' }}>
                  {['in-person', 'virtual'].map(type => (
                    <label key={type} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', fontSize: '0.875rem', color: form.type === type ? 'var(--color-accent-blue)' : 'var(--text-secondary)' }}>
                      <input type="radio" value={type} checked={form.type === type} onChange={() => setForm({ ...form, type })} />
                      {type === 'virtual' ? <><Video size={14} /> Virtual</> : <><MapPin size={14} /> In-Person</>}
                    </label>
                  ))}
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Notes</label>
                <textarea className="form-input" rows={3} placeholder="Meeting agenda or notes..." value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} />
              </div>
              <div style={{ display: 'flex', gap: '0.75rem' }}>
                <button type="button" className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" style={{ flex: 1 }}>
                  <CheckCircle size={15} /> Schedule Meeting
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
