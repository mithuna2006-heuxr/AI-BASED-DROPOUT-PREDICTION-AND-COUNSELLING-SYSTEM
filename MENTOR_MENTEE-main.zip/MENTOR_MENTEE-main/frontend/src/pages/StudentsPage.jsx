import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { quickSort, getRiskGradient } from '../utils/mlEngine';
import { Search, Filter, RefreshCw, UserCheck, AlertTriangle, SortDesc } from 'lucide-react';
import toast from 'react-hot-toast';

export default function StudentsPage() {
  const { students, mentors, reassignMentor, stats } = useData();
  const [search, setSearch] = useState('');
  const [filterRisk, setFilterRisk] = useState('All');
  const [filterDept, setFilterDept] = useState('All');
  const [sortBy, setSortBy] = useState('predicted_risk');
  const [selectedStudent, setSelectedStudent] = useState(null);

  const departments = ['All', ...new Set(students.map(s => s.department))];

  const filtered = students
    .filter(s => {
      const matchSearch = s.name?.toLowerCase().includes(search.toLowerCase()) || s.id?.includes(search);
      const matchRisk = filterRisk === 'All' || s.risk_level === filterRisk;
      const matchDept = filterDept === 'All' || s.department === filterDept;
      return matchSearch && matchRisk && matchDept;
    });

  const sorted = quickSort(filtered, sortBy, true);

  const RISK_BADGE = {
    High: 'badge-high',
    Medium: 'badge-medium',
    Low: 'badge-low'
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div style={{ marginBottom: '1.5rem', display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', fontWeight: 700 }}>Student Management</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
            {filtered.length} students • AI-sorted by risk level
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <span className="badge badge-high">High: {stats.highRisk}</span>
          <span className="badge badge-medium">Med: {stats.mediumRisk}</span>
          <span className="badge badge-low">Low: {stats.lowRisk}</span>
        </div>
      </div>

      {/* Filters */}
      <div className="card" style={{ marginBottom: '1.5rem', padding: '1rem' }}>
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', alignItems: 'center' }}>
          <div style={{ flex: 1, minWidth: '200px', position: 'relative' }}>
            <Search size={15} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              type="text"
              className="form-input"
              placeholder="Search by name or ID..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{ paddingLeft: '2.25rem' }}
            />
          </div>
          
          <select className="form-input form-select" value={filterRisk} onChange={e => setFilterRisk(e.target.value)} style={{ width: 'auto', minWidth: '130px' }}>
            <option value="All">All Risk</option>
            <option value="High">High Risk</option>
            <option value="Medium">Medium Risk</option>
            <option value="Low">Low Risk</option>
          </select>

          <select className="form-input form-select" value={filterDept} onChange={e => setFilterDept(e.target.value)} style={{ width: 'auto', minWidth: '130px' }}>
            {departments.map(d => <option key={d}>{d}</option>)}
          </select>

          <select className="form-input form-select" value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ width: 'auto', minWidth: '140px' }}>
            <option value="predicted_risk">Sort: Risk ↓</option>
            <option value="marks">Sort: Marks</option>
            <option value="attendance">Sort: Attendance</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="card" style={{ padding: 0 }}>
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Student</th>
                <th>Dept</th>
                <th>Attendance</th>
                <th>Marks</th>
                <th>Behaviour</th>
                <th>Financial</th>
                <th>Risk Score</th>
                <th>Risk Level</th>
                <th>Attendance Status</th>
                <th>Mentor</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map(student => (
                <tr key={student.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <div className="avatar avatar-sm" style={{
                        background: student.risk_level === 'High' 
                          ? 'linear-gradient(135deg, #fc8181, #e53e3e)'
                          : student.risk_level === 'Medium'
                          ? 'linear-gradient(135deg, #f6d860, #d69e2e)'
                          : 'linear-gradient(135deg, #48bb78, #38a169)'
                      }}>
                        {student.name?.[0] || '?'}
                      </div>
                      <div>
                        <div style={{ fontWeight: 600, fontSize: '0.875rem' }}>{student.name}</div>
                        <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{student.id}</div>
                      </div>
                    </div>
                  </td>
                  <td><span className="badge badge-info">{student.department}</span></td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <span style={{ fontWeight: 600, color: student.attendance < 60 ? 'var(--risk-high)' : 'var(--text-primary)', fontSize: '0.875rem' }}>
                        {student.attendance}%
                      </span>
                    </div>
                  </td>
                  <td>
                    <span style={{ fontWeight: 600, color: student.marks < 50 ? 'var(--risk-high)' : 'var(--text-primary)', fontSize: '0.875rem' }}>
                      {student.marks}%
                    </span>
                  </td>
                  <td>
                    <div style={{ display: 'flex', gap: '2px' }}>
                      {[1,2,3,4,5].map(i => (
                        <div key={i} style={{
                          width: '8px', height: '8px', borderRadius: '2px',
                          background: i <= (student.behaviour || 3) ? 'var(--color-accent-blue)' : 'rgba(255,255,255,0.1)'
                        }} />
                      ))}
                    </div>
                  </td>
                  <td>
                    {student.financial_issue
                      ? <span className="badge badge-high">⚠ Yes</span>
                      : <span className="badge badge-low">No</span>
                    }
                  </td>
                  <td>
                    <div>
                      <div style={{ fontWeight: 700, color: getRiskGradient(student.predicted_risk).includes('fc') ? 'var(--risk-high)' : student.predicted_risk >= 35 ? 'var(--risk-medium)' : 'var(--risk-low)', fontSize: '0.9rem' }}>
                        {student.predicted_risk}%
                      </div>
                      <div style={{ width: '80px', height: '3px', background: 'rgba(255,255,255,0.05)', borderRadius: '999px', marginTop: '4px' }}>
                        <div style={{
                          height: '100%',
                          width: `${student.predicted_risk}%`,
                          background: getRiskGradient(student.predicted_risk),
                          borderRadius: '999px'
                        }} />
                      </div>
                    </div>
                  </td>
                  <td>
                    <span className={`badge ${RISK_BADGE[student.risk_level]}`}>
                      {student.risk_level}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${student.attendance_status === 'present' ? 'badge-low' : 'badge-high'}`}>
                      {student.attendance_status || 'absent'}
                    </span>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>
                      {student.last_attendance ? new Date(student.last_attendance).toLocaleString() : 'No attendance yet'}
                    </div>
                  </td>
                  <td style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                    {student.assigned_mentor || <span style={{ color: 'var(--text-muted)' }}>Unassigned</span>}
                  </td>
                  <td>
                    <div style={{ display: 'flex', gap: '0.4rem' }}>
                      <button
                        className="btn btn-ghost btn-icon"
                        onClick={() => setSelectedStudent(student)}
                        title="View Details"
                        style={{ padding: '6px' }}
                      >
                        👁️
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {sorted.length === 0 && (
                <tr>
                  <td colSpan={10} style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
                    No students found matching your filters
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Student Detail Modal */}
      {selectedStudent && (
        <div className="modal-overlay" onClick={() => setSelectedStudent(null)}>
          <div className="modal animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <div className="avatar avatar-lg" style={{
                  background: selectedStudent.risk_level === 'High'
                    ? 'linear-gradient(135deg, #fc8181, #e53e3e)'
                    : selectedStudent.risk_level === 'Medium'
                    ? 'linear-gradient(135deg, #f6d860, #d69e2e)'
                    : 'linear-gradient(135deg, #48bb78, #38a169)'
                }}>
                  {selectedStudent.name?.[0]}
                </div>
                <div>
                  <div className="modal-title">{selectedStudent.name}</div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{selectedStudent.id} • {selectedStudent.department}</div>
                </div>
              </div>
              <button className="btn btn-ghost btn-icon" onClick={() => setSelectedStudent(null)}>✕</button>
            </div>

            {/* Risk Score Big Display */}
            <div style={{
              background: selectedStudent.risk_level === 'High' ? 'rgba(252,129,129,0.08)' : selectedStudent.risk_level === 'Medium' ? 'rgba(246,216,96,0.08)' : 'rgba(72,187,120,0.08)',
              border: `1px solid ${selectedStudent.risk_level === 'High' ? 'rgba(252,129,129,0.2)' : selectedStudent.risk_level === 'Medium' ? 'rgba(246,216,96,0.2)' : 'rgba(72,187,120,0.2)'}`,
              borderRadius: '12px',
              padding: '1.25rem',
              marginBottom: '1.25rem',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}>
              <div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>AI Risk Score</div>
                <div style={{ fontSize: '2.5rem', fontWeight: 800, fontFamily: 'var(--font-display)',
                  color: selectedStudent.risk_level === 'High' ? 'var(--risk-high)' : selectedStudent.risk_level === 'Medium' ? 'var(--risk-medium)' : 'var(--risk-low)'
                }}>
                  {selectedStudent.predicted_risk}%
                </div>
              </div>
              <span className={`badge ${RISK_BADGE[selectedStudent.risk_level]}`} style={{ fontSize: '0.9rem', padding: '6px 14px' }}>
                {selectedStudent.risk_level} Risk
              </span>
            </div>

            {/* Metrics */}
            <div className="grid-2" style={{ marginBottom: '1.25rem' }}>
              {[
                { label: 'Attendance', value: `${selectedStudent.attendance}%`, warn: selectedStudent.attendance < 60 },
                { label: 'Marks', value: `${selectedStudent.marks}%`, warn: selectedStudent.marks < 50 },
                { label: 'Behaviour', value: `${selectedStudent.behaviour}/5`, warn: selectedStudent.behaviour < 3 },
                { label: 'Financial Issue', value: selectedStudent.financial_issue ? 'Yes' : 'No', warn: selectedStudent.financial_issue }
              ].map(m => (
                <div key={m.label} style={{
                  padding: '0.875rem', background: 'rgba(255,255,255,0.03)',
                  borderRadius: '10px', border: '1px solid var(--color-border)'
                }}>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>{m.label}</div>
                  <div style={{ fontSize: '1.1rem', fontWeight: 700, color: m.warn ? 'var(--risk-high)' : 'var(--text-primary)', marginTop: '4px' }}>
                    {m.value}
                  </div>
                </div>
              ))}
            </div>

            {selectedStudent.issue_feedback && (
              <div className="alert alert-warning" style={{ marginBottom: '1.25rem' }}>
                <AlertTriangle size={16} />
                <div>
                  <div style={{ fontWeight: 600, fontSize: '0.8rem' }}>Issue Feedback</div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{selectedStudent.issue_feedback}</div>
                </div>
              </div>
            )}

            {/* Reassign Mentor */}
            <div style={{ marginBottom: '1rem' }}>
              <label className="form-label">Reassign Mentor</label>
              <select
                className="form-input form-select"
                value={selectedStudent.mentor_id || ''}
                onChange={e => {
                  reassignMentor(selectedStudent.id, e.target.value);
                  setSelectedStudent(prev => ({ ...prev, mentor_id: e.target.value }));
                  toast.success('Mentor reassigned!');
                }}
              >
                <option value="">Select Mentor</option>
                {mentors.map(m => (
                  <option key={m.id} value={m.id}>{m.name} — {m.department}</option>
                ))}
              </select>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem' }}>
              <button
                className="btn btn-danger"
                style={{ flex: 1 }}
                onClick={() => {
                  sendAlert(selectedStudent.id, 'Urgent: Please meet your mentor. Risk level is critical.');
                  toast.success('Alert sent!');
                }}
              >
                📧 Send Alert Email
              </button>
              <button className="btn btn-outline" onClick={() => setSelectedStudent(null)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
