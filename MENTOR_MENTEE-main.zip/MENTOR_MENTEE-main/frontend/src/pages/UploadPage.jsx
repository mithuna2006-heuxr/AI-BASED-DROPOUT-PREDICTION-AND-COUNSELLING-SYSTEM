import React, { useRef, useState } from 'react';
import { useData } from '../contexts/DataContext';
import * as XLSX from 'xlsx';
import toast from 'react-hot-toast';
import { Upload, FileSpreadsheet, CheckCircle, XCircle, AlertTriangle, Download, Trash2 } from 'lucide-react';

const EXPECTED_FIELDS = ['Student', 'Department', 'Attendance', 'Marks', 'Behaviour', 'Financial_Issue'];

export default function UploadPage() {
  const { importExcelData, loading, students } = useData();
  const fileRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [preview, setPreview] = useState(null);
  const [fileName, setFileName] = useState('');
  const [processing, setProcessing] = useState(false);
  const [step, setStep] = useState(1); // 1=upload, 2=preview, 3=done

  const parseFile = (file) => {
    if (!file) return;
    const allowed = ['xlsx', 'xls', 'csv'];
    const ext = file.name.split('.').pop().toLowerCase();
    if (!allowed.includes(ext)) {
      toast.error('Only Excel (.xlsx, .xls) or CSV files supported');
      return;
    }

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const workbook = XLSX.read(e.target.result, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(sheet);
        
        if (!json.length) {
          toast.error('File is empty');
          return;
        }
        
        setPreview(json);
        setStep(2);
        toast.success(`Parsed ${json.length} rows from ${file.name}`);
      } catch (err) {
        toast.error('Failed to parse file: ' + err.message);
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    parseFile(file);
  };

  const handleImport = async () => {
    setProcessing(true);
    await importExcelData(preview);
    setProcessing(false);
    setStep(3);
    toast.success(`✅ Imported & AI predictions generated!`);
  };

  const downloadTemplate = () => {
    const templateData = [
      {
        Student: 'John Doe',
        Department: 'CSE',
        Attendance: 75,
        Marks: 68,
        Behaviour: 3,
        Financial_Issue: 0,
        Issue_Feedback: 'No issues'
      },
      {
        Student: 'Jane Smith',
        Department: 'ECE',
        Attendance: 40,
        Marks: 35,
        Behaviour: 2,
        Financial_Issue: 1,
        Issue_Feedback: 'Financial difficulties'
      }
    ];
    
    const ws = XLSX.utils.json_to_sheet(templateData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Students');
    XLSX.writeFile(wb, 'mentoriq_template.xlsx');
    toast.success('Template downloaded!');
  };

  const reset = () => {
    setPreview(null);
    setFileName('');
    setStep(1);
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div style={{ marginBottom: '2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 700 }}>Data Import & Processing</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
            Upload Excel files to import student data and trigger AI risk predictions
          </p>
        </div>
        <button className="btn btn-outline" onClick={downloadTemplate}>
          <Download size={16} /> Download Template
        </button>
      </div>

      {/* Progress Steps */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '2rem' }}>
        {[
          { num: 1, label: 'Upload File' },
          { num: 2, label: 'Preview & Validate' },
          { num: 3, label: 'Import Complete' }
        ].map((s, i, arr) => (
          <React.Fragment key={s.num}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <div style={{
                width: '32px', height: '32px', borderRadius: '50%',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '0.85rem', fontWeight: 700,
                background: step >= s.num ? 'var(--gradient-brand)' : 'rgba(255,255,255,0.05)',
                color: step >= s.num ? 'white' : 'var(--text-muted)',
                border: step >= s.num ? 'none' : '1px solid var(--color-border)',
                transition: 'all 0.3s'
              }}>
                {step > s.num ? '✓' : s.num}
              </div>
              <span style={{ fontSize: '0.8rem', fontWeight: step === s.num ? 600 : 400, color: step >= s.num ? 'var(--text-primary)' : 'var(--text-muted)' }}>
                {s.label}
              </span>
            </div>
            {i < arr.length - 1 && (
              <div style={{ flex: 1, height: '1px', background: step > s.num ? 'var(--color-accent-blue)' : 'var(--color-border)', transition: 'background 0.3s' }} />
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Step 1: Upload */}
      {step === 1 && (
        <div className="card animate-slide-up">
          <div
            className={`upload-zone ${dragOver ? 'drag-over' : ''}`}
            onDrop={handleDrop}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onClick={() => fileRef.current?.click()}
          >
            <span className="upload-icon">📊</span>
            <div className="upload-text">Drop your Excel file here</div>
            <div className="upload-hint">or click to browse (.xlsx, .xls, .csv)</div>
            
            <div style={{ marginTop: '2rem', display: 'flex', gap: '0.5rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              {EXPECTED_FIELDS.map(f => (
                <span key={f} className="badge badge-info">{f}</span>
              ))}
            </div>
            
            <input
              ref={fileRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={e => parseFile(e.target.files[0])}
              style={{ display: 'none' }}
            />
          </div>

          {/* Required Fields Info */}
          <div className="alert alert-warning" style={{ marginTop: '1.5rem' }}>
            <AlertTriangle size={16} />
            <div>
              <div style={{ fontWeight: 600, fontSize: '0.875rem' }}>Required Columns</div>
              <div style={{ fontSize: '0.8rem', marginTop: '4px', color: 'var(--text-secondary)' }}>
                Student, Department, Attendance (%), Marks (%), Behaviour (1-5), Financial_Issue (0 or 1)
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step 2: Preview */}
      {step === 2 && preview && (
        <div className="animate-slide-up">
          {/* Validation Summary */}
          <div className="grid-3" style={{ marginBottom: '1.5rem' }}>
            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--color-accent-blue)' }}>{preview.length}</div>
              <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Total Rows</div>
            </div>
            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--color-accent-green)' }}>
                {preview.filter(r => EXPECTED_FIELDS.every(f => r[f] !== undefined)).length}
              </div>
              <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Valid Rows</div>
            </div>
            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--risk-high)' }}>
                {preview.filter(r => !EXPECTED_FIELDS.every(f => r[f] !== undefined)).length}
              </div>
              <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Missing Fields</div>
            </div>
          </div>

          {/* Preview Table */}
          <div className="card" style={{ marginBottom: '1.5rem' }}>
            <div className="card-header">
              <div>
                <div className="card-title">📄 Data Preview — {fileName}</div>
                <div className="card-subtitle">AI risk prediction will be calculated on import</div>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={reset}>
                <Trash2 size={14} /> Reset
              </button>
            </div>
            
            <div className="table-container" style={{ maxHeight: '350px', overflowY: 'auto' }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>#</th>
                    {Object.keys(preview[0] || {}).slice(0, 8).map(k => <th key={k}>{k}</th>)}
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {preview.slice(0, 20).map((row, i) => {
                    const isValid = EXPECTED_FIELDS.every(f => row[f] !== undefined);
                    return (
                      <tr key={i}>
                        <td style={{ color: 'var(--text-muted)' }}>{i + 1}</td>
                        {Object.values(row).slice(0, 8).map((v, j) => (
                          <td key={j}>{String(v)}</td>
                        ))}
                        <td>
                          {isValid
                            ? <span className="badge badge-low"><CheckCircle size={10} /> Valid</span>
                            : <span className="badge badge-high"><XCircle size={10} /> Incomplete</span>
                          }
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {preview.length > 20 && (
                <div style={{ padding: '0.75rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                  ... and {preview.length - 20} more rows
                </div>
              )}
            </div>
          </div>

          {/* AI Processing Info */}
          <div className="card" style={{
            background: 'linear-gradient(135deg, rgba(102,126,234,0.08) 0%, rgba(159,122,234,0.08) 100%)',
            border: '1px solid rgba(159,122,234,0.2)',
            marginBottom: '1.5rem'
          }}>
            <div style={{ fontSize: '0.875rem', fontWeight: 600, marginBottom: '1rem' }}>🤖 AI Processing Pipeline</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.75rem', fontSize: '0.8rem' }}>
              {[
                { icon: '🧹', step: '1. Data Cleaning', desc: 'Normalize & validate fields' },
                { icon: '📐', step: '2. Linear Regression', desc: 'Calculate Predicted Risk score' },
                { icon: '🏷️', step: '3. Risk Classification', desc: 'Low / Medium / High labels' },
                { icon: '⚡', step: '4. QuickSort', desc: 'Sort by risk priority' },
                { icon: '👥', step: '5. Auto-Allocation', desc: 'Assign mentors by dept' },
                { icon: '💾', step: '6. Database Save', desc: 'Store to Firebase/MongoDB' }
              ].map(item => (
                <div key={item.step} style={{
                  padding: '0.75rem', background: 'rgba(255,255,255,0.03)',
                  borderRadius: '10px', border: '1px solid rgba(255,255,255,0.06)'
                }}>
                  <span style={{ fontSize: '1.1rem' }}>{item.icon}</span>
                  <div style={{ fontWeight: 600, marginTop: '0.25rem', color: 'var(--text-primary)' }}>{item.step}</div>
                  <div style={{ color: 'var(--text-muted)', marginTop: '2px' }}>{item.desc}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: 'flex', gap: '1rem' }}>
            <button className="btn btn-ghost" onClick={reset}>← Back</button>
            <button
              className="btn btn-primary"
              style={{ flex: 1 }}
              onClick={handleImport}
              disabled={processing || loading}
            >
              {processing ? (
                <><div className="spinner" style={{ width: '16px', height: '16px' }} /> Processing with AI...</>
              ) : (
                <><FileSpreadsheet size={16} /> Import & Run AI Predictions</>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Done */}
      {step === 3 && (
        <div className="card animate-slide-up" style={{ textAlign: 'center', padding: '3rem' }}>
          <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🎉</div>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 700, marginBottom: '0.5rem' }}>
            Import Complete!
          </h3>
          <p style={{ color: 'var(--text-muted)', marginBottom: '2rem' }}>
            {preview?.length} students imported with AI risk predictions and mentor assignments
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
            <button className="btn btn-outline" onClick={reset}>Upload More</button>
            <button className="btn btn-primary" onClick={() => window.location.href = '/students'}>
              View Students →
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
