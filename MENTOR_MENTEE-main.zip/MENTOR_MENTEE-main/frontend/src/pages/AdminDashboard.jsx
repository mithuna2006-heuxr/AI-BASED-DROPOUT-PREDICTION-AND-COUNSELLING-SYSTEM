import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { useNavigate } from 'react-router-dom';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { Users, AlertTriangle, CheckCircle, Upload, Cpu, Calendar, ArrowRight, Activity } from 'lucide-react';
import { getRiskGradient } from '../utils/mlEngine';

const RISK_COLORS = {
  High: '#fc8181',
  Medium: '#f6d860',
  Low: '#48bb78'
};

const DEPT_COLORS = ['#667eea', '#9f7aea', '#0bc5ea', '#48bb78', '#ed8936', '#fc8181'];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: 'rgba(10,22,40,0.95)', border: '1px solid rgba(99,179,237,0.2)',
      borderRadius: '10px', padding: '0.75rem 1rem', fontSize: '0.8rem'
    }}>
      <p style={{ color: 'var(--text-muted)', marginBottom: '4px' }}>{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color || 'var(--text-primary)', fontWeight: 600 }}>
          {p.name}: {p.value}
        </p>
      ))}
    </div>
  );
};

export default function AdminDashboard() {
  const { students, mentors, meetings, stats } = useData();
  const navigate = useNavigate();

  // Trend data (last 7 days)
  const trendData = [...Array(7)].map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return {
      day: d.toLocaleDateString('en', { weekday: 'short' }),
      attendance: Math.floor(Math.random() * 30) + 40,
      risk: Math.floor(Math.random() * 20) + 30
    };
  });

  // Dept data
  const deptData = stats.deptStats.map((d, i) => ({
    ...d,
    fill: DEPT_COLORS[i % DEPT_COLORS.length]
  }));

  // Risk distribution
  const riskPieData = [
    { name: 'High Risk', value: stats.highRisk, color: '#fc8181' },
    { name: 'Medium Risk', value: stats.mediumRisk, color: '#f6d860' },
    { name: 'Low Risk', value: stats.lowRisk, color: '#48bb78' }
  ];

  // Top high risk students
  const highRiskStudents = students
    .filter(s => s.risk_level === 'High')
    .sort((a, b) => b.predicted_risk - a.predicted_risk)
    .slice(0, 5);

  return (
    <div className="animate-fade-in">
      {/* Welcome Banner */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(102,126,234,0.15) 0%, rgba(11,197,234,0.1) 100%)',
        border: '1px solid rgba(99,179,237,0.2)',
        borderRadius: '16px',
        padding: '1.5rem 2rem',
        marginBottom: '2rem',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '1rem'
      }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 700, marginBottom: '0.25rem' }}>
            Welcome back, <span style={{ background: 'var(--gradient-brand)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Administrator</span> 👋
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
            {stats.highRisk > 0 
              ? `⚠️ ${stats.highRisk} high-risk students require immediate attention`
              : '✅ All students are performing well today'
            }
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button className="btn btn-outline btn-sm" onClick={() => navigate('/esp32')}>
            <Cpu size={14} /> ESP32 Device
          </button>
          <button className="btn btn-primary btn-sm" onClick={() => navigate('/upload')}>
            <Upload size={14} /> Upload Data
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(99,179,237,0.1)' }}>
            <Users size={20} color="var(--color-accent-blue)" />
          </div>
          <div className="stat-value">{stats.totalStudents}</div>
          <div className="stat-label">Total Students</div>
          <div className="stat-change positive">↑ Active Monitoring</div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(252,129,129,0.1)' }}>
            <AlertTriangle size={20} color="var(--risk-high)" />
          </div>
          <div className="stat-value" style={{ color: 'var(--risk-high)' }}>{stats.highRisk}</div>
          <div className="stat-label">High Risk</div>
          <div className="stat-change negative">⚠ Needs Attention</div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(72,187,120,0.1)' }}>
            <Activity size={20} color="var(--color-accent-green)" />
          </div>
          <div className="stat-value" style={{ color: 'var(--color-accent-green)' }}>{stats.attendanceToday}</div>
          <div className="stat-label">Attendance Today</div>
          <div className="stat-change positive">↑ IoT Verified</div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(159,122,234,0.1)' }}>
            <Users size={20} color="var(--color-accent-purple)" />
          </div>
          <div className="stat-value">{stats.totalMentors}</div>
          <div className="stat-label">Active Mentors</div>
          <div className="stat-change positive">↑ All Assigned</div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(246,216,96,0.1)' }}>
            <Calendar size={20} color="var(--risk-medium)" />
          </div>
          <div className="stat-value">{stats.totalMeetings}</div>
          <div className="stat-label">Meetings</div>
          <div className="stat-change positive">↑ This Month</div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(72,187,120,0.1)' }}>
            <CheckCircle size={20} color="var(--color-accent-green)" />
          </div>
          <div className="stat-value">{stats.lowRisk}</div>
          <div className="stat-label">Low Risk</div>
          <div className="stat-change positive">↑ Performing Well</div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid-3" style={{ marginBottom: '1.5rem' }}>
        {/* Trend Chart */}
        <div className="card" style={{ gridColumn: 'span 2' }}>
          <div className="card-header">
            <div>
              <div className="card-title">Attendance & Risk Trend</div>
              <div className="card-subtitle">Last 7 days overview</div>
            </div>
            <span className="badge badge-info">Live</span>
          </div>
          <div className="chart-wrapper" style={{ height: '220px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="attGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#63b3ed" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#63b3ed" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="riskGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#fc8181" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#fc8181" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: '0.75rem' }} />
                <Area type="monotone" dataKey="attendance" stroke="#63b3ed" fill="url(#attGrad)" strokeWidth={2} name="Attendance" />
                <Area type="monotone" dataKey="risk" stroke="#fc8181" fill="url(#riskGrad)" strokeWidth={2} name="Avg Risk" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Risk Pie */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Risk Distribution</div>
          </div>
          <div className="chart-wrapper" style={{ height: '160px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={riskPieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} padAngle={3} dataKey="value">
                  {riskPieData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} stroke="transparent" />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
            {riskPieData.map(item => (
              <div key={item.name} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.78rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: item.color }} />
                  <span style={{ color: 'var(--text-secondary)' }}>{item.name}</span>
                </div>
                <span style={{ fontWeight: 700, color: item.color }}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid-2" style={{ marginBottom: '1.5rem' }}>
        {/* Department Bar Chart */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Avg Risk by Department</div>
          </div>
          <div className="chart-wrapper" style={{ height: '200px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={deptData} barSize={28}>
                <XAxis dataKey="name" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 11 }} axisLine={false} tickLine={false} domain={[0, 100]} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="avgRisk" name="Avg Risk" radius={[6,6,0,0]}>
                  {deptData.map((entry, i) => (
                    <Cell key={i} fill={entry.avgRisk >= 60 ? '#fc8181' : entry.avgRisk >= 40 ? '#f6d860' : '#48bb78'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* High Risk Students */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">⚠️ High Risk Students</div>
            <button className="btn btn-ghost btn-sm" onClick={() => navigate('/students')}>
              View All <ArrowRight size={14} />
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {highRiskStudents.length === 0 && (
              <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', textAlign: 'center', padding: '1rem' }}>
                No high-risk students 🎉
              </p>
            )}
            {highRiskStudents.map(student => (
              <div key={student.id} style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.75rem', background: 'rgba(252,129,129,0.04)',
                borderRadius: '10px', border: '1px solid rgba(252,129,129,0.1)'
              }}>
                <div className="avatar avatar-sm" style={{
                  background: `linear-gradient(135deg, #fc8181, #e53e3e)`
                }}>
                  {student.name?.[0] || '?'}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '0.85rem', fontWeight: 600 }}>{student.name}</div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{student.department}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--risk-high)' }}>
                    {student.predicted_risk}%
                  </div>
                  <div style={{ width: '60px', height: '4px', background: 'rgba(255,255,255,0.05)', borderRadius: '999px', marginTop: '4px' }}>
                    <div style={{ height: '100%', width: `${student.predicted_risk}%`, background: 'var(--gradient-danger)', borderRadius: '999px' }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">Quick Actions</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '1rem' }}>
          {[
            { icon: '📤', label: 'Upload Excel', path: '/upload', color: 'var(--color-accent-blue)' },
            { icon: '🤖', label: 'Run AI Prediction', path: '/students', color: 'var(--color-accent-purple)' },
            { icon: '📡', label: 'Connect ESP32', path: '/esp32', color: 'var(--color-accent-cyan)' },
            { icon: '🕸️', label: 'Neural Graph', path: '/neural', color: 'var(--color-accent-green)' },
            { icon: '📅', label: 'Schedule Meeting', path: '/meetings', color: 'var(--risk-medium)' },
            { icon: '📱', label: 'Manage Devices', path: '/devices', color: 'var(--risk-high)' },
          ].map(action => (
            <button
              key={action.label}
              className="btn btn-ghost"
              style={{
                flexDirection: 'column', gap: '0.5rem', padding: '1.25rem',
                border: '1px solid var(--color-border)', borderRadius: '12px',
                fontSize: '0.85rem', fontWeight: 600, color: action.color,
                transition: 'all 0.2s'
              }}
              onClick={() => navigate(action.path)}
            >
              <span style={{ fontSize: '1.5rem' }}>{action.icon}</span>
              {action.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
