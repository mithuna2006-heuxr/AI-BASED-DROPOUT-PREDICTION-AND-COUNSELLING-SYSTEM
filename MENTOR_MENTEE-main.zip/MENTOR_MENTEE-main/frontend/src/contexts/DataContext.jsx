import React, { createContext, useContext, useMemo, useState, useEffect, useCallback } from 'react';
import { allocateMentors, calculateRisk, classifyRisk, getDeptStats, processStudentData, quickSort } from '../utils/mlEngine';

const DataContext = createContext(null);
export const useData = () => useContext(DataContext);

const now = () => new Date().toISOString();

const DEMO_MENTORS = [
  { id: 'M001', name: 'Dr. Priya Sharma', department: 'CSE', email: 'priya.sharma@college.edu', specialization: 'Machine Learning' },
  { id: 'M002', name: 'Prof. Ramesh Kumar', department: 'ECE', email: 'ramesh.kumar@college.edu', specialization: 'VLSI Design' },
  { id: 'M003', name: 'Dr. Anita Singh', department: 'MECH', email: 'anita.singh@college.edu', specialization: 'Thermal Engineering' },
];

const DEMO_STUDENTS = [
  {
    student_id: 'STU001',
    name: 'Arjun Mehta',
    department: 'CSE',
    attendance: 45,
    marks: 38,
    behaviour: 2,
    financial_issue: true,
    predicted_risk: 72.5,
    issue_feedback: 'Family financial crisis affecting studies',
    mentor_id: 'M001',
    fingerprint_id: 101,
    last_attendance: now(),
    attendance_status: 'present',
  },
  {
    student_id: 'STU002',
    name: 'Sneha Reddy',
    department: 'CSE',
    attendance: 82,
    marks: 78,
    behaviour: 4,
    financial_issue: false,
    predicted_risk: 22.1,
    issue_feedback: '',
    mentor_id: 'M001',
    fingerprint_id: 102,
    last_attendance: null,
    attendance_status: 'absent',
  },
  {
    student_id: 'STU003',
    name: 'Karthik Nair',
    department: 'ECE',
    attendance: 60,
    marks: 55,
    behaviour: 3,
    financial_issue: false,
    predicted_risk: 48.3,
    issue_feedback: 'Health issues',
    mentor_id: 'M002',
    fingerprint_id: 103,
    last_attendance: now(),
    attendance_status: 'present',
  },
  {
    student_id: 'STU004',
    name: 'Divya Krishnan',
    department: 'ECE',
    attendance: 35,
    marks: 30,
    behaviour: 2,
    financial_issue: true,
    predicted_risk: 85.0,
    issue_feedback: 'Absenteeism and financial difficulties',
    mentor_id: 'M002',
    fingerprint_id: 104,
    last_attendance: null,
    attendance_status: 'absent',
  },
  {
    student_id: 'STU005',
    name: 'Rohan Patel',
    department: 'MECH',
    attendance: 91,
    marks: 88,
    behaviour: 5,
    financial_issue: false,
    predicted_risk: 8.5,
    issue_feedback: '',
    mentor_id: 'M003',
    fingerprint_id: 105,
    last_attendance: now(),
    attendance_status: 'present',
  },
  {
    student_id: 'STU006',
    name: 'Preethi Suresh',
    department: 'MECH',
    attendance: 72,
    marks: 65,
    behaviour: 3,
    financial_issue: false,
    predicted_risk: 35.8,
    issue_feedback: '',
    mentor_id: 'M003',
    fingerprint_id: 106,
    last_attendance: null,
    attendance_status: 'absent',
  },
  {
    student_id: 'STU007',
    name: 'Akash Verma',
    department: 'CSE',
    attendance: 50,
    marks: 42,
    behaviour: 2,
    financial_issue: true,
    predicted_risk: 68.2,
    issue_feedback: 'Part-time job affecting attendance',
    mentor_id: 'M001',
    fingerprint_id: 107,
    last_attendance: null,
    attendance_status: 'absent',
  },
  {
    student_id: 'STU008',
    name: 'Lavanya Gopalan',
    department: 'ECE',
    attendance: 88,
    marks: 82,
    behaviour: 4,
    financial_issue: false,
    predicted_risk: 18.3,
    issue_feedback: '',
    mentor_id: 'M002',
    fingerprint_id: 108,
    last_attendance: now(),
    attendance_status: 'present',
  },
].map(student => ({
  ...student,
  id: student.student_id,
  risk_level: classifyRisk(student.predicted_risk),
  assigned_mentor: DEMO_MENTORS.find(mentor => mentor.id === student.mentor_id)?.name || '',
  created_at: now(),
}));

const DEMO_MEETINGS = [
  { meeting_id: 'MTG001', mentor_id: 'M001', student_id: 'STU001', date: '2026-04-10', status: 'scheduled' },
  { meeting_id: 'MTG002', mentor_id: 'M001', student_id: 'STU002', date: '2026-04-08', status: 'attended' },
  { meeting_id: 'MTG003', mentor_id: 'M002', student_id: 'STU004', date: '2026-04-09', status: 'scheduled' },
].map(meeting => ({ ...meeting, id: meeting.meeting_id, created_at: now() }));

const DEMO_DEVICES = [
  { device_id: 'ESP32-001', ip_address: '192.168.1.105', status: 'connected', last_seen: now() },
];

function normalizeStudent(student, mentors) {
  const studentId = student.student_id || student.id || `STU_${Math.random().toString(36).slice(2, 9).toUpperCase()}`;
  const predictedRisk = typeof student.predicted_risk === 'number'
    ? student.predicted_risk
    : calculateRisk(student.attendance || 0, student.marks || 0, student.behaviour || 3, student.financial_issue ? 1 : 0);

  const mentor = mentors.find(item => item.id === student.mentor_id);

  return {
    id: studentId,
    student_id: studentId,
    name: student.name || 'Unknown',
    department: student.department || 'General',
    attendance: Number(student.attendance || 0),
    marks: Number(student.marks || 0),
    behaviour: Number(student.behaviour || 3),
    financial_issue: Boolean(student.financial_issue),
    predicted_risk: Math.round(predictedRisk * 10) / 10,
    issue_feedback: student.issue_feedback || '',
    mentor_id: student.mentor_id || '',
    assigned_mentor: student.assigned_mentor || mentor?.name || '',
    fingerprint_id: Number(student.fingerprint_id || 0),
    last_attendance: student.last_attendance || null,
    attendance_status: student.attendance_status || 'absent',
    risk_level: student.risk_level || classifyRisk(predictedRisk),
    created_at: student.created_at || now(),
  };
}

function normalizeMeeting(meeting) {
  const meetingId = meeting.meeting_id || meeting.id || `MTG_${Math.random().toString(36).slice(2, 9).toUpperCase()}`;
  return {
    id: meetingId,
    meeting_id: meetingId,
    mentor_id: meeting.mentor_id || '',
    student_id: meeting.student_id || '',
    date: meeting.date || new Date().toISOString().slice(0, 10),
    status: meeting.status || 'scheduled',
    created_at: meeting.created_at || now(),
  };
}

function normalizeDevice(device) {
  const deviceId = device.device_id || device.id || `DEV_${Math.random().toString(36).slice(2, 9).toUpperCase()}`;
  return {
    id: deviceId,
    device_id: deviceId,
    ip_address: device.ip_address || '',
    status: device.status || 'offline',
    last_seen: device.last_seen || null,
  };
}

export const DataProvider = ({ children }) => {
  const [students, setStudents] = useState(() => DEMO_STUDENTS.map(student => normalizeStudent(student, DEMO_MENTORS)));
  const [mentors, setMentors] = useState(() => DEMO_MENTORS);
  const [meetings, setMeetings] = useState(() => DEMO_MEETINGS.map(normalizeMeeting));
  const [devices, setDevices] = useState(() => DEMO_DEVICES.map(normalizeDevice));
  const [esp32Connected, setEsp32Connected] = useState(false);
  const [esp32IP, setEsp32IP] = useState('');
  const [esp32Logs, setEsp32Logs] = useState([]);
  const [loading, setLoading] = useState(false);

  const addLog = useCallback((type, message) => {
    setEsp32Logs(prev => [{ type, message, timestamp: new Date().toLocaleTimeString() }, ...prev].slice(0, 50));
  }, []);

  const recalculateStudentRisk = useCallback((student) => {
    const predicted_risk = calculateRisk(student.attendance, student.marks, student.behaviour, student.financial_issue ? 1 : 0);
    return {
      ...student,
      predicted_risk: Math.round(predicted_risk * 10) / 10,
      risk_level: classifyRisk(predicted_risk),
    };
  }, []);

  const assignMentors = useCallback((studentList, mentorList) => {
    const sortedStudents = quickSort(studentList, 'predicted_risk', true);
    return allocateMentors(sortedStudents, mentorList).map(student => normalizeStudent(student, mentorList));
  }, []);

  const importExcelData = useCallback(async (jsonData) => {
    setLoading(true);
    try {
      const processed = processStudentData(jsonData);
      const allocated = assignMentors(processed, mentors);
      setStudents(prev => [...prev, ...allocated]);
      addLog('success', `Imported ${allocated.length} students into the students collection`);
    } catch (error) {
      addLog('error', `Failed to import students: ${error.message}`);
    } finally {
      setLoading(false);
    }
  }, [addLog, assignMentors, mentors]);

  const updateStudent = useCallback((studentId, updates) => {
    setStudents(prev => prev.map(student => {
      if (student.student_id !== studentId) return student;
      const nextStudent = normalizeStudent({ ...student, ...updates }, mentors);
      return recalculateStudentRisk(nextStudent);
    }));
  }, [mentors, recalculateStudentRisk]);

  const updateMentorAssignment = useCallback((studentId, mentorId) => {
    const mentor = mentors.find(item => item.id === mentorId);
    updateStudent(studentId, {
      mentor_id: mentorId,
      assigned_mentor: mentor?.name || '',
    });
  }, [mentors, updateStudent]);

  const updateDevice = useCallback((deviceId, updates) => {
    setDevices(prev => {
      const exists = prev.some(device => device.device_id === deviceId || device.id === deviceId);
      const nextDevice = normalizeDevice({ device_id: deviceId, ...prev.find(device => device.device_id === deviceId || device.id === deviceId), ...updates });
      return exists
        ? prev.map(device => (device.device_id === deviceId || device.id === deviceId ? nextDevice : device))
        : [nextDevice, ...prev];
    });
  }, []);

  const updateAttendanceByFingerprint = useCallback((fingerprintId, deviceId, payload = {}) => {
    const matchedStudent = students.find(student => Number(student.fingerprint_id) === Number(fingerprintId));
    if (!matchedStudent) {
      addLog('error', `No student found for fingerprint_id ${fingerprintId}`);
      return null;
    }

    const updatedStudent = recalculateStudentRisk({
      ...matchedStudent,
      attendance: Math.min(100, Number(matchedStudent.attendance || 0) + 1),
      last_attendance: new Date().toISOString(),
      attendance_status: 'present',
      ...payload,
    });

    setStudents(prev => prev.map(student => (student.student_id === matchedStudent.student_id ? updatedStudent : student)));
    updateDevice(deviceId || 'ESP32-001', {
      status: 'connected',
      last_seen: new Date().toISOString(),
      ip_address: payload.ip_address || esp32IP || '',
    });

    addLog('success', `Attendance updated for ${updatedStudent.name} via fingerprint ${fingerprintId}`);
    return updatedStudent;
  }, [addLog, esp32IP, recalculateStudentRisk, students, updateDevice]);

  const connectESP32 = useCallback(async (ipAddress) => {
    if (!ipAddress) return;
    if (!/^(\d{1,3}\.){3}\d{1,3}$/.test(ipAddress)) {
      addLog('error', 'Invalid IP address format');
      return;
    }

    setEsp32IP(ipAddress);
    addLog('info', `Connecting to ESP32 at ${ipAddress}...`);

    try {
      const response = await fetch(`http://${ipAddress}/data`, { method: 'GET', mode: 'cors' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const deviceData = await response.json();
      const deviceId = deviceData.device_id || 'ESP32-001';
      updateDevice(deviceId, {
        ip_address: ipAddress,
        status: 'connected',
        last_seen: new Date().toISOString(),
      });
      setEsp32Connected(true);
      addLog('success', `Connected to ${deviceId} at ${ipAddress}`);

      if (deviceData.fingerprint_id || deviceData.student_id) {
        updateAttendanceByFingerprint(deviceData.fingerprint_id || deviceData.student_id, deviceId, {
          ip_address: ipAddress,
        });
      }
    } catch (error) {
      updateDevice('ESP32-001', {
        ip_address: ipAddress,
        status: 'connected',
        last_seen: new Date().toISOString(),
      });
      setEsp32Connected(true);
      addLog('success', `[DEMO] Device connected at ${ipAddress}`);
    }
  }, [addLog, updateAttendanceByFingerprint, updateDevice]);

  const disconnectESP32 = useCallback(() => {
    setEsp32Connected(false);
    setEsp32IP('');
    updateDevice('ESP32-001', { status: 'offline', last_seen: new Date().toISOString() });
    addLog('info', 'Disconnected from ESP32 device');
  }, [addLog, updateDevice]);

  const scheduleMeeting = useCallback((meetingData) => {
    const nextMeeting = normalizeMeeting({
      ...meetingData,
      meeting_id: meetingData.meeting_id || `MTG${Date.now()}`,
      status: meetingData.status || 'scheduled',
    });

    setMeetings(prev => [nextMeeting, ...prev]);

    if (nextMeeting.status === 'missed') {
      addLog('info', `Missed meeting detected for ${nextMeeting.student_id}; backend should trigger Gmail API email.`);
    }
  }, [addLog]);

  const updateMeetingStatus = useCallback((meetingId, status) => {
    setMeetings(prev => prev.map(meeting => {
      if (meeting.meeting_id !== meetingId && meeting.id !== meetingId) return meeting;
      const updated = normalizeMeeting({ ...meeting, status });
      if (status === 'missed') {
        addLog('info', `Meeting ${meetingId} marked missed. Gmail email should be sent by backend.`);
      }
      return updated;
    }));
  }, [addLog]);

  const triggerMissedMeetingEmail = useCallback((meeting) => {
    addLog('info', `Missed meeting email requested for student ${meeting.student_id} and mentor ${meeting.mentor_id}`);
  }, [addLog]);

  const stats = useMemo(() => {
    const highRiskStudents = students.filter(student => student.risk_level === 'High').length;
    const mediumRiskStudents = students.filter(student => student.risk_level === 'Medium').length;
    const lowRiskStudents = students.filter(student => student.risk_level === 'Low').length;
    const activeAttendanceToday = students.filter(student => {
      if (!student.last_attendance) return false;
      return new Date(student.last_attendance).toDateString() === new Date().toDateString();
    }).length;

    return {
      totalStudents: students.length,
      highRisk: highRiskStudents,
      mediumRisk: mediumRiskStudents,
      lowRisk: lowRiskStudents,
      totalMentors: mentors.length,
      totalMeetings: meetings.length,
      totalDevices: devices.length,
      activeDevices: devices.filter(device => device.status === 'connected').length,
      attendanceToday: activeAttendanceToday,
      deptStats: getDeptStats(students),
    };
  }, [devices, meetings, mentors.length, students]);

  const attendance = useMemo(() => students
    .filter(student => student.last_attendance)
    .map(student => ({
      id: `ATT_${student.student_id}`,
      student_id: student.student_id,
      timestamp: student.last_attendance,
      status: student.attendance_status === 'present' ? 'verified' : 'failed',
      method: 'fingerprint',
      device_ip: esp32IP || '',
    }))
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)), [students, esp32IP]);

  const alerts = useMemo(() => [], []);

  useEffect(() => {
    setStudents(prev => prev.map(student => normalizeStudent(student, mentors)));
  }, [mentors]);

  const value = {
    students,
    setStudents,
    mentors,
    setMentors,
    meetings,
    setMeetings,
    devices,
    setDevices,
    attendance,
    alerts,
    esp32Connected,
    esp32IP,
    esp32Logs,
    stats,
    loading,
    importExcelData,
    connectESP32,
    disconnectESP32,
    updateStudent,
    updateMentorAssignment,
    updateDevice,
    updateAttendanceByFingerprint,
    scheduleMeeting,
    updateMeetingStatus,
    triggerMissedMeetingEmail,
    recalculateStudentRisk,
    reassignMentor: updateMentorAssignment,
    sendAlert: (studentId, message) => {
      const student = students.find(item => item.student_id === studentId || item.id === studentId);
      addLog('info', `Email request prepared for ${student?.name || studentId}: ${message}`);
    },
    addAlert: (type, message) => addLog(type, message),
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};
