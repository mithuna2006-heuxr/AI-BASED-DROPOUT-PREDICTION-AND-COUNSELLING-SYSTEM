import React, { createContext, useContext, useState, useEffect } from 'react';
import { auth, googleProvider } from '../utils/firebase';
import {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from 'firebase/auth';

const AuthContext = createContext(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

// Demo users for offline/demo mode (no Firebase needed)
const DEMO_USERS = {
  admin: {
    uid: 'demo-admin-001',
    email: 'admin@mentoriq.edu',
    displayName: 'System Administrator',
    role: 'admin',
    photoURL: null
  },
  mentor: {
    uid: 'demo-mentor-001',
    email: 'dr.sharma@mentoriq.edu',
    displayName: 'Dr. Priya Sharma',
    role: 'mentor',
    department: 'Computer Science',
    photoURL: null
  },
  student: {
    uid: 'demo-student-001',
    email: 'student@mentoriq.edu',
    displayName: 'Rahul Kumar',
    role: 'student',
    department: 'Computer Science',
    photoURL: null
  }
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState('');
  const [loading, setLoading] = useState(true);
  const [demoMode, setDemoMode] = useState(false);

  useEffect(() => {
    // Check for persisted demo session
    const savedDemo = sessionStorage.getItem('mentor_demo_user');
    if (savedDemo) {
      const demoUser = JSON.parse(savedDemo);
      setUser(demoUser);
      setUserRole(demoUser.role);
      setDemoMode(true);
      setLoading(false);
      return;
    }

    let unsubscribe = () => {};
    try {
      unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
        if (firebaseUser) {
          // Get stored role from localStorage
          const storedRole = localStorage.getItem(`role_${firebaseUser.uid}`) || 'student';
          setUser({ ...firebaseUser, role: storedRole });
          setUserRole(storedRole);
        } else {
          setUser(null);
          setUserRole('');
        }
        setLoading(false);
      });
    } catch (err) {
      // Firebase not configured - just continue
      setLoading(false);
    }
    return unsubscribe;
  }, []);

  const loginWithGoogle = async (role = 'student') => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const firebaseUser = result.user;
      localStorage.setItem(`role_${firebaseUser.uid}`, role);
      setUserRole(role);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const loginWithEmail = async (email, password, role = 'student') => {
    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      localStorage.setItem(`role_${result.user.uid}`, role);
      setUserRole(role);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const registerWithEmail = async (email, password, name, role = 'student') => {
    try {
      const result = await createUserWithEmailAndPassword(auth, email, password);
      localStorage.setItem(`role_${result.user.uid}`, role);
      setUserRole(role);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  // Demo login (no Firebase required)
  const loginDemo = (role) => {
    const demoUser = DEMO_USERS[role] || DEMO_USERS.student;
    sessionStorage.setItem('mentor_demo_user', JSON.stringify(demoUser));
    setUser(demoUser);
    setUserRole(demoUser.role);
    setDemoMode(true);
    return { success: true };
  };

  const logout = async () => {
    sessionStorage.removeItem('mentor_demo_user');
    setDemoMode(false);
    if (!demoMode) {
      try { await signOut(auth); } catch {}
    }
    setUser(null);
    setUserRole('');
  };

  const value = {
    user,
    userRole,
    loading,
    demoMode,
    loginWithGoogle,
    loginWithEmail,
    registerWithEmail,
    loginDemo,
    logout,
    isAdmin: userRole === 'admin',
    isMentor: userRole === 'mentor',
    isStudent: userRole === 'student'
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
