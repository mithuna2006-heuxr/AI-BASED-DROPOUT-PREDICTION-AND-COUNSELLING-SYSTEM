// Firebase Configuration
// Replace these with your actual Firebase project credentials from:
// https://console.firebase.google.com → Project Settings → Your Apps

import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCNjsfQ_iKKKJxPGCKjvNmnmv-Dh_Dl8Fk",
  authDomain: "systamatic-pen.firebaseapp.com",
  projectId: "systamatic-pen",
  storageBucket: "systamatic-pen.firebasestorage.app",
  messagingSenderId: "573313642759",
  appId: "1:573313642759:web:baac13ef497d87a99955a2",
  measurementId: "G-68M4Z89VSV"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();

googleProvider.setCustomParameters({
  prompt: 'select_account'
});

export default app;
