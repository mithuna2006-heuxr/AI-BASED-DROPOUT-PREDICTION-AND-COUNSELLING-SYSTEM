// ML Utility Functions
// Linear Regression - Predicted Risk Calculation
// AI Engine for Mentor-Mentee System

/**
 * Weights for risk prediction linear regression model
 * Based on importance of each factor for student risk assessment
 */
const WEIGHTS = {
  attendance: -0.4,    // lower attendance = higher risk
  marks: -0.35,        // lower marks = higher risk
  behaviour: -0.15,    // poor behaviour = higher risk
  financial_issue: 0.1 // financial issue = higher risk
};

const BIAS = 100; // base risk score offset

/**
 * Calculate Predicted Risk using Linear Regression
 * @param {number} attendance - Attendance percentage (0-100)
 * @param {number} marks - Average marks percentage (0-100)
 * @param {number} behaviour - Behaviour score (1-5, 5=excellent)
 * @param {number} financial_issue - 1=yes, 0=no
 * @returns {number} Risk score (0-100)
 */
export const calculateRisk = (attendance, marks, behaviour, financial_issue) => {
  const normalizedBehaviour = ((behaviour - 1) / 4) * 100; // normalize 1-5 to 0-100
  
  const riskScore = BIAS
    + (WEIGHTS.attendance * attendance)
    + (WEIGHTS.marks * marks)
    + (WEIGHTS.behaviour * normalizedBehaviour)
    + (WEIGHTS.financial_issue * (financial_issue ? 50 : 0));
  
  return Math.max(0, Math.min(100, riskScore));
};

/**
 * Classify risk level based on score
 * @param {number} riskScore 
 * @returns {'High'|'Medium'|'Low'}
 */
export const classifyRisk = (riskScore) => {
  if (riskScore >= 65) return 'High';
  if (riskScore >= 35) return 'Medium';
  return 'Low';
};

/**
 * QuickSort implementation for sorting students by risk
 * @param {Array} arr - Array of student objects
 * @param {string} key - Sort key
 * @param {boolean} descending - Sort order
 * @returns {Array} Sorted array
 */
export const quickSort = (arr, key = 'predicted_risk', descending = true) => {
  if (!arr || arr.length <= 1) return arr;
  
  const pivot = arr[Math.floor(arr.length / 2)];
  const pivotVal = pivot[key] ?? 0;
  
  const left = arr.filter((item, i) => {
    const val = item[key] ?? 0;
    return i !== Math.floor(arr.length / 2) && (descending ? val > pivotVal : val < pivotVal);
  });
  
  const middle = arr.filter(item => (item[key] ?? 0) === pivotVal);
  
  const right = arr.filter((item, i) => {
    const val = item[key] ?? 0;
    return i !== Math.floor(arr.length / 2) && (descending ? val <= pivotVal : val >= pivotVal);
  });
  
  // Fix: correct boundary
  const leftFiltered = arr.filter((item, i) => {
    const val = item[key] ?? 0;
    if (descending) return val > pivotVal;
    return val < pivotVal;
  });
  const rightFiltered = arr.filter(item => {
    const val = item[key] ?? 0;
    if (descending) return val < pivotVal;
    return val > pivotVal;
  });
  
  return [
    ...quickSort(leftFiltered, key, descending),
    ...middle,
    ...quickSort(rightFiltered, key, descending)
  ];
};

/**
 * Automatic Mentor Allocation Algorithm
 * Groups by department and assigns mentors balancing high-risk students
 * @param {Array} students - Sorted student array
 * @param {Array} mentors - Available mentors
 * @returns {Array} Students with assigned mentor
 */
export const allocateMentors = (students, mentors) => {
  if (!students.length || !mentors.length) return students;
  
  // Group by department
  const byDept = {};
  students.forEach(student => {
    const dept = student.department || 'General';
    if (!byDept[dept]) byDept[dept] = [];
    byDept[dept].push(student);
  });
  
  // Group mentors by department preference
  const mentorsByDept = {};
  mentors.forEach(mentor => {
    const dept = mentor.department || 'General';
    if (!mentorsByDept[dept]) mentorsByDept[dept] = [];
    mentorsByDept[dept].push({ ...mentor, assignedCount: 0 });
  });
  
  const allocated = [];
  
  Object.entries(byDept).forEach(([dept, deptStudents]) => {
    const deptMentors = mentorsByDept[dept] || mentorsByDept['General'] || mentors;
    if (!deptMentors || !deptMentors.length) {
      allocated.push(...deptStudents);
      return;
    }
    
    // Sort dept students by risk (high first)
    const sorted = quickSort(deptStudents, 'predicted_risk', true);
    
    sorted.forEach(student => {
      // Find mentor with least assignments
      const mentor = deptMentors.reduce((min, m) => 
        m.assignedCount < min.assignedCount ? m : min
      );
      
      mentor.assignedCount++;
      allocated.push({
        ...student,
        mentor_id: mentor.id,
        assigned_mentor: mentor.name
      });
    });
  });
  
  return allocated;
};

/**
 * Process Excel data and add AI predictions
 * @param {Array} rawData 
 * @returns {Array} Processed data with risk predictions
 */
export const processStudentData = (rawData) => {
  return rawData.map(student => {
    const attendance = parseFloat(student.Attendance || student.attendance) || 0;
    const marks = parseFloat(student.Marks || student.marks) || 0;
    const behaviour = parseFloat(student.Behaviour || student.behaviour) || 3;
    const financial = parseInt(student.Financial_Issue || student.financial_issue) || 0;
    const fingerprintId = parseInt(student.fingerprint_id || student.Fingerprint_ID || student.FingerprintId || 0, 10) || 0;
    
    const predicted_risk = calculateRisk(attendance, marks, behaviour, financial);
    const risk_level = classifyRisk(predicted_risk);
    const studentId = student.student_id || student.Student_ID || student.id || `STU_${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    return {
      id: studentId,
      student_id: studentId,
      name: student.Student || student.name || 'Unknown',
      department: student.Department || student.department || 'General',
      attendance,
      marks,
      behaviour,
      financial_issue: !!financial,
      predicted_risk: Math.round(predicted_risk * 10) / 10,
      risk_level,
      issue_feedback: student.Issue_Feedback || student.issue_feedback || '',
      fingerprint_id: fingerprintId,
      last_attendance: student.last_attendance || null,
      attendance_status: student.attendance_status || 'absent',
      mentor_id: student.mentor_id || '',
      created_at: new Date().toISOString(),
      attendance_history: []
    };
  });
};

/**
 * Calculate department statistics
 */
export const getDeptStats = (students) => {
  const depts = {};
  students.forEach(s => {
    const d = s.department || 'General';
    if (!depts[d]) depts[d] = { name: d, total: 0, high: 0, medium: 0, low: 0, avgRisk: 0 };
    depts[d].total++;
    depts[d].avgRisk += s.predicted_risk || 0;
    if (s.risk_level === 'High') depts[d].high++;
    else if (s.risk_level === 'Medium') depts[d].medium++;
    else depts[d].low++;
  });
  
  return Object.values(depts).map(d => ({
    ...d,
    avgRisk: Math.round((d.avgRisk / d.total) * 10) / 10
  }));
};

export const getRiskColor = (level) => {
  if (level === 'High') return 'var(--risk-high)';
  if (level === 'Medium') return 'var(--risk-medium)';
  return 'var(--risk-low)';
};

export const getRiskGradient = (score) => {
  if (score >= 65) return 'linear-gradient(90deg, #e53e3e, #fc8181)';
  if (score >= 35) return 'linear-gradient(90deg, #d69e2e, #f6d860)';
  return 'linear-gradient(90deg, #38a169, #48bb78)';
};
